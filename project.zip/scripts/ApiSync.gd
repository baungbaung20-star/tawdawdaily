extends Node

# ---------------------------------------------------------------
# ApiSync - api.thaistock2d.com ကနေ 2D ရလဒ်တွေ ယူပေးတဲ့ အပိုင်း
# (UI မပါပါ။ Main.gd နဲ့ signal တွေကနေပဲ ဆက်သွယ်တယ်)
#
# အလုပ်လုပ်ပုံ (တစ်ခုပြီးမှ တစ်ခု):
#   1. /live             -> ယနေ့ (သို့) နောက်ဆုံး အလုပ်လုပ်ခဲ့တဲ့နေ့ရဲ့ ရလဒ်
#                           (response ပုံစံ တကယ်စမ်းပြီး အတည်ပြုထားတာ)
#   2. /2d_result        -> နောက်ဆုံး ရက် ၁၀ ရက်စာ     (docs အရ၊ မစမ်းရသေး)
#   3. /2d_result?date=  -> ကျန်နေတဲ့ ရက်တွေကို တစ်ရက်ချင်း (docs အရ၊ မစမ်းရသေး)
#
# Response ပုံစံ မသိတာ တွေ့ရင် data မသိမ်းဘဲ note ပြန်ပေးတယ်။
# ---------------------------------------------------------------

signal progress(text: String)
# slots = အရှည် ၄ ခုပါတဲ့ Array၊ တစ်ခုချင်းစီက {"twod": "", "set": "", "val": ""}
# checked = true ဆိုရင် အဲဒီရက်ကို နောက်တစ်ခါ ထပ်မမေးတော့ဘူး (ပြီးဆုံးပြီးသား အတိတ်ရက်)
signal day_ready(date: String, slots: Array, checked: bool)
signal finished(ok: bool, message: String)
# /live ရဲ့ "live" အပိုင်း (အခု ပြောင်းနေတဲ့ ဂဏန်း)။ ဈေးမဖွင့်သေး/ပိတ်ထားရင် "--" ကြောင့်
# twod က "" ဖြစ်လာမယ်။ info = {"twod","set","val","time","date"} (အားလုံး String)
signal live_ready(info: Dictionary)

const BASE_URL := "https://api.thaistock2d.com"
const BACKFILL_DAYS := 31
const REQUEST_GAP := 0.4
const MAX_FAILURES := 3
const THAI_UTC_OFFSET := 7 * 3600
# 11:00, 12:01, 15:00, 16:30 (မိနစ်ပေါင်း)
const SLOT_MINUTES := [660, 721, 900, 990]
const SLOT_TOLERANCE := 45

var _http: HTTPRequest
var _live_http: HTTPRequest   # /live ကို ခဏခဏ မေးဖို့ သီးသန့် (sync လုပ်နေတာနဲ့ မတိုက်အောင်)
var _live_busy := false
var _live_fail_count := 0
var _live_pause_until := 0    # Time.get_ticks_msec() ဒီတန်ဖိုးမရောက်သေးရင် မမေးဘူး
var _busy := false
var _skip: Dictionary = {}
var _seen: Dictionary = {}
var _queue: Array = []
var _stage := ""
var _current_date := ""
var _failures := 0
var _notes: Array = []


func _ready() -> void:
	_http = HTTPRequest.new()
	_http.timeout = 20.0
	add_child(_http)
	_http.request_completed.connect(_on_request_completed)

	_live_http = HTTPRequest.new()
	_live_http.timeout = 15.0
	add_child(_live_http)
	_live_http.request_completed.connect(_on_live_completed)


# ထိုင်းအချိန်အရ ယနေ့ရက်စွဲ (ရလဒ်တွေကို ထိုင်းရက်စွဲနဲ့ သိမ်းတယ်)
static func thai_today() -> String:
	return Time.get_date_string_from_unix_time(int(Time.get_unix_time_from_system()) + THAI_UTC_OFFSET)


func is_busy() -> bool:
	return _busy


# skip_dates = ပြည့်စုံပြီးသား (သို့) စစ်ပြီးသား ရက်စွဲတွေ { "2026-11-06": true }
func start(skip_dates: Dictionary) -> void:
	if _busy:
		return
	_busy = true
	_skip = skip_dates
	_seen = {}
	_queue = []
	_failures = 0
	_notes = []
	_request("live", "")


# ---------- Request ----------

func _request(stage: String, date: String) -> void:
	_stage = stage
	_current_date = date
	var url := BASE_URL + "/live"
	if stage == "recent":
		url = BASE_URL + "/2d_result"
	elif stage == "day":
		var p := date.split("-")  # YYYY-MM-DD -> API က DD-MM-YYYY သုံးတယ်
		url = "%s/2d_result?date=%s-%s-%s" % [BASE_URL, p[2], p[1], p[0]]
	progress.emit(_progress_text())
	var err := _http.request(url)
	if err != OK:
		_finish(false, "Could not start the request (error %d)" % err)


func _progress_text() -> String:
	if _stage == "live":
		return "Checking latest results..."
	if _stage == "recent":
		return "Loading recent days..."
	return "Filling gaps: %s (%d left)" % [_current_date, _queue.size()]


func _on_request_completed(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	var parsed: Variant = null
	var ok := (result == HTTPRequest.RESULT_SUCCESS and code == 200)
	if ok:
		parsed = JSON.parse_string(body.get_string_from_utf8())
		ok = (parsed != null)

	if ok:
		_handle_response(parsed)
	else:
		_failures += 1
		push_warning("2D: '%s' request failed (result=%d, http=%d)" % [_stage, result, code])
		if _stage == "live":
			_finish(false, "Server not reachable")
			return
		if _failures >= MAX_FAILURES:
			_finish(false, "Too many failed requests")
			return

	await get_tree().create_timer(REQUEST_GAP).timeout
	_advance()


# ---------- Response ကို ကိုင်တွယ်ခြင်း ----------

func _handle_response(parsed: Variant) -> void:
	if _stage == "live":
		if not _process_live(parsed):
			var live_note := "live: unexpected response format"
			_notes.append(live_note)
			push_warning("2D: " + live_note)
		return

	var days: Variant = _parse_days(parsed, _current_date)
	if days == null:
		var note := "%s: unexpected response format" % _stage
		_notes.append(note)
		push_warning("2D: " + note)
		return

	var dd: Dictionary = days
	var today := thai_today()
	if dd.is_empty() and _stage != "day":
		_notes.append("%s: no usable rows" % _stage)

	for key in dd:
		var date := str(key)
		var slots := _rows_to_slots(dd[key])
		if _stage != "day":
			_seen[date] = true
		# live က အခု ပြောင်းနေဆဲ ဖြစ်နိုင်လို့ checked မလုပ်ဘူး။ အတိတ်ရက်ပဲ checked လုပ်တယ်
		var checked := (_stage != "live" and date < today)
		day_ready.emit(date, slots, checked)

	# ရက်တစ်ရက် တောင်းထားပြီး data မပါလာရင် (ပိတ်ရက်) checked လုပ်ပြီး နောက်ထပ်မမေးတော့ဘူး
	if _stage == "day" and not dd.has(_current_date) and _current_date < today:
		day_ready.emit(_current_date, _empty_slots(), true)


# ---------- /live (Live panel အတွက် + ထွက်ပြီးသား ရလဒ်တွေ) ----------

# Sync မလုပ်ဘဲ /live ကိုပဲ တစ်ခါမေးတယ် (Main က ဈေးဖွင့်ချိန် ခဏခဏ ခေါ်တယ်)
func fetch_live() -> void:
	if _live_busy or Time.get_ticks_msec() < _live_pause_until:
		return
	_live_busy = true
	var err := _live_http.request(BASE_URL + "/live")
	if err != OK:
		_live_busy = false


func _on_live_completed(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	_live_busy = false
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		# ခဏခဏမေးတာမို့ မအောင်ရင် တိတ်တိတ်ကျော်၊ ရှိပြီးသား ပြထားတာကို မပြောင်းဘူး။
		# ဆက်တိုက် ၃ ခါ မအောင်ရင် (ဥပမာ offline၊ ကန့်သတ်ခံရ) ၁ မိနစ် ရပ်စောင့်တယ်
		_live_fail_count += 1
		if _live_fail_count >= 3:
			_live_fail_count = 0
			_live_pause_until = Time.get_ticks_msec() + 60000
		return
	_live_fail_count = 0
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if parsed != null:
		_process_live(parsed)


# {"live": {...}, "result": [ rows ]} -> live_ready + (result ထဲက) day_ready
func _process_live(parsed: Variant) -> bool:
	if not (parsed is Dictionary):
		return false
	var pd: Dictionary = parsed
	live_ready.emit(_live_info(pd.get("live")))

	var days: Variant = _parse_days(pd, "")
	if days != null:
		var dd: Dictionary = days
		for key in dd:
			var date := str(key)
			_seen[date] = true
			# live က အခု ပြောင်းနေဆဲ ဖြစ်နိုင်လို့ checked မလုပ်ဘူး
			day_ready.emit(date, _rows_to_slots(dd[key]), false)
	return true


func _live_info(v: Variant) -> Dictionary:
	var info := {"twod": "", "set": "", "val": "", "time": "", "date": ""}
	if v is Dictionary:
		var d: Dictionary = v
		var twod := str(d.get("twod", "")).strip_edges()
		if _is_two_digits(twod):  # "--" ဆိုရင် မလာသေးဘူးလို့ သတ်မှတ်
			info["twod"] = twod
			info["set"] = _clean_num(str(d.get("set", "")))
			info["val"] = _clean_num(str(d.get("value", "")))
			info["time"] = str(d.get("time", "")).strip_edges()
			info["date"] = _norm_date(str(d.get("date", "")))
	return info


func _advance() -> void:
	if _stage == "live":
		_request("recent", "")
	elif _stage == "recent":
		_build_queue()
		_next_day()
	else:
		_next_day()


func _build_queue() -> void:
	_queue = []
	var today := thai_today()
	var now := int(Time.get_unix_time_from_system()) + THAI_UTC_OFFSET
	for i in range(BACKFILL_DAYS):
		var ts := now - i * 86400
		var wd: int = Time.get_datetime_dict_from_unix_time(ts).weekday
		if wd == 0 or wd == 6:
			continue  # တနင်္ဂနွေ၊ စနေ ဈေးပိတ်
		var d := Time.get_date_string_from_unix_time(ts)
		# ယနေ့ကို /live က ကိုင်ပြီးသား၊ ပြည့်စုံပြီးသား/စစ်ပြီးသား/ယခုရပြီးသား ရက်တွေကို ကျော်
		if d == today or _skip.has(d) or _seen.has(d):
			continue
		_queue.append(d)


func _next_day() -> void:
	if _queue.is_empty():
		_finish(true, "; ".join(PackedStringArray(_notes)))
		return
	_request("day", str(_queue.pop_front()))


func _finish(ok: bool, message: String) -> void:
	_busy = false
	finished.emit(ok, message)


# ---------- Response ပုံစံ ခွဲခြားခြင်း ----------
# သိတဲ့ ပုံစံတွေ:
#   {"result": [ {row + stock_date}, ... ]}        (/live)
#   [ {"date": "...", "child": [ rows ]}, ... ]    (docs ရဲ့ 2d_result)
#   {"child": [ rows ]}
# ပြန်ပေးတာ: { "YYYY-MM-DD": [rows] }၊ ပုံစံမသိရင် null

func _parse_days(parsed: Variant, fallback_date: String) -> Variant:
	var out := {}
	if parsed is Dictionary:
		var pd: Dictionary = parsed
		if pd.has("child") and pd["child"] is Array:
			_group_rows(pd["child"], _norm_date(str(pd.get("date", fallback_date))), out)
			return out
		if pd.has("result") and pd["result"] is Array:
			_group_rows(pd["result"], fallback_date, out)
			return out
		return null
	if parsed is Array:
		var pa: Array = parsed
		for item in pa:
			if not (item is Dictionary):
				return null
			var d: Dictionary = item
			if d.has("child") and d["child"] is Array:
				_group_rows(d["child"], _norm_date(str(d.get("date", fallback_date))), out)
			elif d.has("twod"):
				_group_rows([d], fallback_date, out)
			else:
				return null
		return out
	return null


func _group_rows(rows: Array, day_hint: String, out: Dictionary) -> void:
	for r in rows:
		if not (r is Dictionary):
			continue
		var row: Dictionary = r
		var d := _norm_date(str(row.get("stock_date", row.get("date", day_hint))))
		if d == "":
			continue
		if not out.has(d):
			out[d] = []
		out[d].append(row)


# "2026-11-06" / "06-11-2026" / "2026-11-06 11:00:02" -> "2026-11-06"၊ မမှန်ရင် ""
func _norm_date(s: String) -> String:
	var t := s.strip_edges().substr(0, 10)
	var parts := t.split("-")
	if parts.size() != 3:
		return ""
	for p in parts:
		if not p.is_valid_int():
			return ""
	if parts[0].length() == 4:
		return "%s-%s-%s" % [parts[0], parts[1].pad_zeros(2), parts[2].pad_zeros(2)]
	if parts[2].length() == 4:
		return "%s-%s-%s" % [parts[2], parts[1].pad_zeros(2), parts[0].pad_zeros(2)]
	return ""


func _empty_slots() -> Array:
	var slots: Array = []
	for i in range(4):
		slots.append({"twod": "", "set": "", "val": ""})
	return slots


# ရလဒ် row တွေကို အချိန်အလိုက် အကွက် ၄ ကွက်ထဲ ခွဲထည့်တယ်
func _rows_to_slots(rows: Array) -> Array:
	var slots: Array = _empty_slots()
	var best_id: Array = [-1, -1, -1, -1]
	for r in rows:
		var row: Dictionary = r
		var idx := _slot_index(str(row.get("open_time", row.get("time", ""))))
		if idx < 0:
			continue
		var twod := str(row.get("twod", "")).strip_edges()
		if not _is_two_digits(twod):
			continue  # "--" စတာတွေ
		var hid := -1
		var hs := str(row.get("history_id", ""))
		if hs.is_valid_int():
			hid = int(hs)
		# အကွက်တူ row နှစ်ခုပါရင် history_id ပိုကြီးတာ (ပိုနောက်ကျတာ) ကိုယူ
		if str(slots[idx]["twod"]) != "" and hid <= int(best_id[idx]):
			continue
		best_id[idx] = hid
		slots[idx] = {
			"twod": twod,
			"set": _clean_num(str(row.get("set", ""))),
			"val": _clean_num(str(row.get("value", ""))),
		}
	return slots


# "11:00:00" -> 0, "12:01:00" -> 1, "15:00:00" -> 2, "16:30:00" -> 3၊ မကိုက်ရင် -1
func _slot_index(t: String) -> int:
	var parts := t.strip_edges().split(":")
	if parts.size() < 2 or not parts[0].is_valid_int() or not parts[1].is_valid_int():
		return -1
	var mins := int(parts[0]) * 60 + int(parts[1])
	var best := -1
	var best_diff := SLOT_TOLERANCE + 1
	for i in range(SLOT_MINUTES.size()):
		var diff := absi(mins - int(SLOT_MINUTES[i]))
		if diff < best_diff:
			best_diff = diff
			best = i
	return best


func _is_two_digits(s: String) -> bool:
	if s.length() != 2:
		return false
	for i in range(2):
		var c := s.unicode_at(i)
		if c < 48 or c > 57:
			return false
	return true


# "34,559.20" -> "34559.20"၊ ဂဏန်းမဟုတ်ရင် (ဥပမာ "--") ""
func _clean_num(s: String) -> String:
	var t := s.replace(",", "").strip_edges()
	if t.is_valid_float():
		return t
	return ""

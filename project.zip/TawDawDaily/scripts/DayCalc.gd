extends RefCounted
# Excel ဖိုင်ရဲ့ "For Taw Daw" Sheet ကို App ထဲမှာ ပြန်တွက်တဲ့ logic (UI မပါ)။
#
# Input : 12:00 (slot2) နဲ့ 16:30 (slot4) ရဲ့ 2D နံပါတ် ၂ လုံးတွဲ (Excel ရဲ့ C3,D3 နဲ့ G3,H3)
#         (အခြား slot နှစ်ခု A3,B3,E3,F3 ကို Excel မှာ ဘာဖော်မြူလာမှ မသုံးဘူး)
# Output: Excel ရဲ့ cell နာမည်အတိုင်း key (a4, c4, ... a17)၊ လက်ရှိ ပုံစံကို Python နဲ့
#         Excel/LibreOffice တွက်ထားတာနဲ့ တိုက်စစ်ထားတယ်။
#
# A7 = A5&C5&E5&G5၊ E7 = A4&C4&E4&G4 ပါပဲ၊ ဒါပေမဲ့ ဂဏန်းတူ ထပ်ပါနေရင် (ဥပမာ 1886, 9111, 1213)
# REPEAT ဇယားအတိုင်း အစားထိုးတယ် (fix_repeats)။ A8, E8, A10, E10 နဲ့ အောက်က cell တွေက
# အစားထိုးပြီးသား A7 / E7 ကို သုံးတယ်။ A6, E6, A9, E9 က မူလဂဏန်းကိုပဲ သုံးတယ် (Excel အတိုင်း)။

const PI_X := 3.1415926535897
const E_X := 2.718281828459

# ဂဏန်းတူ ၂/၃/၄ ကြိမ် ပါရင် အစားထိုးမယ့် တန်ဖိုး
const REPEAT := {
	"11": "16", "111": "168", "1111": "1680",
	"22": "27", "222": "274", "2222": "2740",
	"33": "38", "333": "385", "3333": "3850",
	"44": "49", "444": "492", "4444": "4920",
	"55": "50", "555": "503", "5555": "5037",
	"66": "61", "666": "619", "6666": "6190",
	"77": "72", "777": "720", "7777": "7205",
	"88": "83", "888": "831", "8888": "8310",
	"99": "94", "999": "946", "9999": "9460",
	"00": "05", "000": "057", "0000": "0573",
}

const BK := {
	"0": "A = 0, B = 05.72, C = 05.83 (BK)",
	"1": "A = 1, B = 16.83, C = 16.49 (BK)",
	"2": "A = 2, B = 27.49, C = 27.50 (BK)",
	"3": "A = 3, B = 38.50, C = 38.61 (BK)",
	"4": "A = 4, B = 49.27, C = 49.16 (BK)",
	"5": "A = 5, B = 50.38, C = 50.27 (BK)",
	"6": "A = 6, B = 61.94, C = 61.38 (BK)",
	"7": "A = 7, B = 72.05, C = 72.94 (BK)",
	"8": "A = 8, B = 83.16, C = 83.05 (BK)",
	"9": "A = 9, B = 94.61, C = 94.72 (BK)",
}


# ၄ လုံးထဲမှာ ဂဏန်းတစ်ခုတည်း ၂/၃/၄ ကြိမ် ပါနေရင် (ဘေးချင်းကပ်မကပ် မခွဲ) REPEAT ဇယားအတိုင်း
# အစားထိုးတယ်။ အစားထိုးတဲ့ စာလုံးတွေကို အဲဒီဂဏန်း ပါနေတဲ့ နေရာတွေမှာ ဘယ်ကနေ ညာ အစဉ်လိုက် ထည့်တယ်။
# ဥပမာ 1886 -> 1836၊ 9111 -> 9168၊ 1213 -> 1263၊ 1122 -> 1627၊ 1212 -> 1267၊ 1234 -> 1234
static func fix_repeats(s: String) -> String:
	var out: Array = []
	for i in range(s.length()):
		out.append(s[i])
	for d in range(10):
		var ds: String = str(d)
		var pos: Array = []
		for i in range(s.length()):
			if s[i] == ds:
				pos.append(i)
		if pos.size() < 2:
			continue
		var key: String = ds.repeat(pos.size())
		var mapped: String = str(REPEAT.get(key, key))
		for k in range(pos.size()):
			if k < mapped.length():
				out[pos[k]] = mapped[k]
	return "".join(PackedStringArray(out))


static func is_two_digits(s: String) -> bool:
	if s.length() != 2:
		return false
	for i in range(2):
		var c: int = s.unicode_at(i)
		if c < 48 or c > 57:
			return false
	return true


# Excel ရဲ့ "General" ကနေ စာသား ပြောင်းတဲ့ ပုံစံ - အဓိပ္ပာယ်ရှိတဲ့ ဂဏန်း ၁၅ လုံးအထိ၊ နောက်ဆုံး သုည တွေ ဖြုတ်
static func excel_text(x: float) -> String:
	if x == 0.0:
		return "0"
	var int_digits: int = str(int(absf(x))).length()
	var decimals: int = maxi(0, 15 - int_digits)
	var s: String = ("%." + str(decimals) + "f") % x
	if s.contains("."):
		s = s.rstrip("0")
		s = s.rstrip(".")
	return s


# ဂဏန်းတစ်လုံးချင်း ထပ်ခါပါတဲ့ အရေအတွက်များတာ အရင်၊ တူရင် အရင်ပေါ်တာ အရင် (Excel SORTBY အတိုင်း)
static func uniq_sorted(s: String) -> String:
	var order: Array = []
	var cnt: Dictionary = {}
	for i in range(s.length()):
		var ch: String = s[i]
		if not cnt.has(ch):
			cnt[ch] = 0
			order.append(ch)
		cnt[ch] = int(cnt[ch]) + 1
	var result: Array = order.duplicate()
	result.sort_custom(func(a, b):
		if int(cnt[a]) != int(cnt[b]):
			return int(cnt[a]) > int(cnt[b])
		return order.find(a) < order.find(b)
	)
	return "".join(PackedStringArray(result))


# s2 = 12:00 ရဲ့ နံပါတ် (ဥပမာ "65")၊ s4 = 16:30 ရဲ့ နံပါတ် (ဥပမာ "90")
# နှစ်ခုလုံး ၂ လုံးတွဲ မဟုတ်ရင် {} ပြန်ပေးတယ်
static func compute(s2: String, s4: String) -> Dictionary:
	if not is_two_digits(s2) or not is_two_digits(s4):
		return {}
	var c3: int = int(s2[0])
	var d3: int = int(s2[1])
	var g3: int = int(s4[0])
	var h3: int = int(s4[1])

	var p1: int = (c3 * d3) % 10
	var p2: int = (g3 * h3) % 10
	var a4: int = (9 + c3 + p1) % 10
	var c4: int = (9 + d3 + p1) % 10
	var e4: int = (9 + g3 + p2) % 10
	var g4: int = (9 + h3 + p2) % 10

	var a5: int = (a4 * 9) % 10
	var c5: int = (c4 * 9) % 10
	var e5: int = (e4 * 9) % 10
	var g5: int = (g4 * 9) % 10

	var blue: String = "%d%d%d%d" % [a5, c5, e5, g5]    # A5&C5&E5&G5
	var green: String = "%d%d%d%d" % [a4, c4, e4, g4]    # A4&C4&E4&G4

	var a6: float = PI_X * float(blue.to_int())
	var e6: float = PI_X * float(green.to_int())

	var a7: String = fix_repeats(blue)
	var e7: String = fix_repeats(green)

	var a8: float = PI_X * float(a7.to_int())
	var e8: float = PI_X * float(e7.to_int())
	var a9: float = E_X * float(blue.to_int())
	var e9: float = E_X * float(green.to_int())
	var a10: float = E_X * float(a7.to_int())
	var e10: float = E_X * float(e7.to_int())

	var a11: String = excel_text(a6).replace(".", "") + excel_text(e6).replace(".", "")
	var e11: String = excel_text(a8).replace(".", "") + excel_text(e8).replace(".", "")
	var a12: String = excel_text(a9).replace(".", "") + excel_text(e9).replace(".", "")
	var e12: String = excel_text(a10).replace(".", "") + excel_text(e10).replace(".", "")
	var a13: String = a11 + e11 + a12 + e12

	var a14: String = uniq_sorted(a11)
	var c14: String = uniq_sorted(e11)
	var e14: String = uniq_sorted(a12)
	var g14: String = uniq_sorted(e12)
	var a15: String = a14.left(4) + c14.left(4) + e14.left(4) + g14.left(4)
	var a16: String = uniq_sorted(a13)
	var e16: String = uniq_sorted(a15)

	var a17: String
	if a16.left(1) == e16.left(1):
		a17 = str(BK[a16.left(1)])
	else:
		a17 = a16.left(1) + e16.left(1)

	return {
		"a4": a4, "c4": c4, "e4": e4, "g4": g4,
		"a5": a5, "c5": c5, "e5": e5, "g5": g5,
		"a6": a6, "e6": e6,
		"a7": a7, "e7": e7,
		"blue": blue, "green": green,
		"a8": a8, "e8": e8,
		"a9": a9, "e9": e9,
		"a10": a10, "e10": e10,
		"a11": a11, "e11": e11,
		"a12": a12, "e12": e12,
		"a13": a13,
		"a14": a14, "c14": c14, "e14": e14, "g14": g14,
		"a15": a15,
		"a16": a16, "e16": e16,
		"a17": a17,
	}


# a17 က ၂ လုံးတွဲ ဂဏန်းလား (မနက်ဖြန်အတွက် A)၊ မဟုတ်ရင် "BK" စာသား
static func is_plain_pair(a17: String) -> bool:
	return is_two_digits(a17)


# ဇယားအတွက် အတိုကောက်: "75" ဒါမှမဟုတ် "BK 7"
static func short_result(a17: String) -> String:
	if is_two_digits(a17):
		return a17
	return "BK " + a17.substr(4, 1)

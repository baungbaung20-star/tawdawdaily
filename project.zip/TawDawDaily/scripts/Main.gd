extends Control

# ---------------------------------------------------------------
# Taw Daw Daily
# - Header row: 11:00 AM | 12:00 PM | 3:00 PM | 4:30 PM
# - ရက်စွဲတစ်ခုချင်းစီအတွက် Entry Block တစ်ခုစီ: ထိပ်မှာ "Weekday, Date" label
#   (+ Edit mode မှာ pencil ခလုတ်) နဲ့ အောက်မှာ အကွက် ၄ ကွက်။
# - အကွက်တစ်ခုစီမှာ 2D နံပါတ်ကို ကြီးကြီးပြပြီး၊ အောက်မှာ SET နဲ့ Value ကို သေးသေးပြတယ်။
# - "+ Add New" နဲ့ pencil က Dialog တစ်ခုတည်းကို သုံးတယ် (Add / Edit)။
# - ဇယားက လ+နှစ် တစ်ခုချင်းစီကိုပဲ ပြတယ်။ Settings (gear) ထဲက Sort နဲ့ ပြောင်းတယ်။
# - App ဖွင့်တိုင်း ApiSync.gd က api.thaistock2d.com ကနေ ရလဒ်တွေ ယူပြီး
#   ကျော်သွားတဲ့ ရက်တွေကိုပါ ဖြည့်ပေးတယ်။ ကိုယ်တိုင်ပြင်ထားတဲ့ အကွက်ကို API က ပြန်မထိဘူး။
# - Data ကို user:// ထဲ JSON နဲ့ သိမ်းပြီး App ပြန်ဖွင့်တိုင်း Load လုပ်တယ်။
# ---------------------------------------------------------------

const ApiSyncScript := preload("res://scripts/ApiSync.gd")
const DayCalcScript := preload("res://scripts/DayCalc.gd")

const SAVE_PATH := "user://daily_data.json"
const STATE_PATH := "user://sync_state.json"

const SLOT_LABELS := ["11:00 AM", "12:00 PM", "3:00 PM", "4:30 PM"]
const SLOT_KEYS := ["slot1", "slot2", "slot3", "slot4"]  # 2D နံပါတ် (Calendar app နဲ့ တူတဲ့ key)
const SET_KEYS := ["set1", "set2", "set3", "set4"]
const VAL_KEYS := ["val1", "val2", "val3", "val4"]
const WEEKDAY_NAMES := ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
const MONTH_NAMES := ["January", "February", "March", "April", "May", "June",
	"July", "August", "September", "October", "November", "December"]
const CELL_MIN_WIDTH := 72
# ဈေးဖွင့်ချိန် (ထိုင်း ၀၉:၃၀–၁၆:၅၀၊ တနင်္လာ–သောကြာ) Live ကို ဘယ်နှစက္ကန့်တစ်ခါ မေးမလဲ။
# (Source က ၇–၈ စက္ကန့်လောက်တစ်ခါ ပြောင်းတယ်၊ ၉ စက္ကန့်ဆိုရင် server ကို ပိုမဝန်ပိဘဲ မကြာလှဘူး)
const LIVE_REFRESH_SECONDS := 9.0
const GEAR_SIZE := Vector2(32, 30)  # Settings ခလုတ်အရွယ် (App ရဲ့ ညာဘက်အပေါ်ထောင့်အစွန်မှာ)

# ---- Theme: accent အရောင် ၇ မျိုး × Light / Dark ----
# အောက်က COLOR_* တွေက Theme ပြောင်းရင် _apply_theme() က ပြန်သတ်မှတ်တယ်။
# (နာမည်ကို "GREEN" လို့ထားထားပေမဲ့ လက်ရှိရွေးထားတဲ့ accent အရောင်ကို ဆိုလိုတယ်)
const COLOR_WARN := Color(0.85, 0.40, 0.05)              # 2D နဲ့ SET/Value မကိုက်ရင်

var COLOR_BG := Color(0.945, 0.965, 0.937)               # page background
var COLOR_WHITE := Color(1, 1, 1)                        # card / panel နောက်ခံ
var COLOR_GREEN := Color(0.227, 0.514, 0.314)            # accent (ခလုတ်၊ header cell)
var COLOR_GREEN_DARK := Color(0.122, 0.302, 0.180)       # ခေါင်းစီး / 2D နံပါတ် (စာအဓိက)
var COLOR_GREEN_MUTED := Color(0.345, 0.478, 0.384)      # စာသေး / subtitle
var COLOR_GREEN_LIGHT := Color(0.906, 0.949, 0.902)      # alt row / input bg
var COLOR_SHADOW := Color(0.227, 0.514, 0.314, 0.18)
var COLOR_DIM := Color(0.08, 0.20, 0.11, 0.45)           # dialog နောက်က မှောင်ကွက်
var COLOR_ON_ACCENT := Color(1, 1, 1)                    # accent ခလုတ်ပေါ်က စာ
var COLOR_ACCENT_TEXT := Color(0.227, 0.514, 0.314)      # card ပေါ်မှာ accent အရောင်စာ
var COLOR_ACCENT_HOVER := Color(0.17, 0.39, 0.24)        # accent ခလုတ် နှိပ်/hover
var COLOR_CHIP_HOVER := Color(0.84, 0.92, 0.84)
var COLOR_TOAST_BG := Color(0.122, 0.302, 0.180, 0.94)
var COLOR_TOAST_FG := Color(1, 1, 1)

var theme_id: String = "green"
var dark_mode: bool = false
var _themes: Array = [
	{"id": "green", "name": "Green", "accent": Color.html("#3A8350")},
	{"id": "red", "name": "Red", "accent": Color.html("#B23B3B")},
	{"id": "yellow", "name": "Yellow", "accent": Color.html("#856A00")},
	{"id": "orange", "name": "Orange", "accent": Color.html("#B4531A")},
	{"id": "blue", "name": "Blue", "accent": Color.html("#2F66A8")},
	{"id": "purple", "name": "Purple", "accent": Color.html("#7048A8")},
	{"id": "pink", "name": "Pink", "accent": Color.html("#B03A75")},
]

var data: Array = []
var checked: Dictionary = {}   # ပြီးဆုံးပြီး စစ်ထားတဲ့ အတိတ်ရက်တွေ (ထပ်မမေးတော့ဘူး)
var bold_font: FontVariation

var header_grid: GridContainer
var entries_vbox: VBoxContainer
var period_label: Label
var toast_panel: PanelContainer
var toast_label: Label
var _toast_tween: Tween
var gear_btn: Button

var filter_month: int
var filter_year: int
var edit_mode: bool = false
var newest_first: bool = true   # true = ရက်အသစ်ဆုံး အပေါ်ဆုံး၊ false = ရက်အသစ်ဆုံး အောက်ဆုံး (ခလုတ်နဲ့ ပြောင်း၊ မှတ်ထားမယ်)
var order_btn: Button
var table_scroll: ScrollContainer
var _first_sync_done: bool = false

var sync = null  # ApiSync.gd instance (type မထည့်ဘူး၊ signal/method ကို dynamic ခေါ်တာမို့)
var notify_plugin = null  # Android plugin "TawDawNotify" (ရှိမှသာ၊ မရှိရင် null = notification menu မပြ)
var _sync_changed_days: int = 0

var live_content: VBoxContainer
var live_time_label: Label
var live_timer: Timer
var _live_signature: String = ""

var clock_label: Label
var _last_live: Dictionary = {}
var clock_timer: Timer


# Font မလိုဘဲ ကိုယ်တိုင်ဆွဲတဲ့ ပြုံးနေတဲ့ မျက်နှာ (Emoji font မရှိတဲ့ စက်မှာလည်း အမြဲပေါ်အောင်)
class SmileyFace extends Control:
	var face_color := Color(1.0, 0.80, 0.25)
	var line_color := Color(0.33, 0.22, 0.05)

	func _init() -> void:
		custom_minimum_size = Vector2(56, 56)

	func _draw() -> void:
		var c: Vector2 = size / 2.0
		var r: float = minf(size.x, size.y) / 2.0 - 2.0
		draw_circle(c, r, face_color)
		draw_arc(c, r, 0.0, TAU, 48, line_color, 2.0, true)
		var eye_r: float = r * 0.10
		draw_circle(c + Vector2(-r * 0.34, -r * 0.22), eye_r, line_color)
		draw_circle(c + Vector2(r * 0.34, -r * 0.22), eye_r, line_color)
		draw_arc(c + Vector2(0.0, -r * 0.02), r * 0.52, PI * 0.18, PI * 0.82, 24, line_color, 2.5, true)


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var parts: PackedStringArray = ApiSyncScript.thai_today().split("-")
	filter_year = int(parts[0])
	filter_month = int(parts[1])
	_prepare_fonts()
	_load_state()
	_apply_theme()
	_build_ui()
	_build_toast()
	_load_data()
	_update_order_button()
	_render_table(true)

	sync = ApiSyncScript.new()
	add_child(sync)
	sync.progress.connect(func(text: String): _show_toast(text, 0.0))
	sync.day_ready.connect(_on_day_ready)
	sync.finished.connect(_on_sync_finished)
	sync.live_ready.connect(_on_live_ready)

	live_timer = Timer.new()
	live_timer.wait_time = LIVE_REFRESH_SECONDS
	live_timer.timeout.connect(_on_live_timer)
	add_child(live_timer)
	live_timer.start()

	# နာရီ: စက္ကန့်မကျော်သွားအောင် 0.25 စက္ကန့်တစ်ခါစစ်ပြီး စာသားပြောင်းမှ update လုပ်တယ်
	clock_timer = Timer.new()
	clock_timer.wait_time = 0.25
	clock_timer.timeout.connect(_update_clock)
	add_child(clock_timer)
	clock_timer.start()

	_setup_notify()
	_start_sync()


# Android မှာ plugin ပါရင်ပဲ ချိတ်တယ်။ ဖွင့်ထားပြီးသားဆိုရင် App ဖွင့်တိုင်း alarm ကို ပြန်ချိန်ပေးတယ်
func _setup_notify() -> void:
	if OS.get_name() != "Android" or not Engine.has_singleton("TawDawNotify"):
		return
	notify_plugin = Engine.get_singleton("TawDawNotify")
	if notify_plugin.isEnabled():
		notify_plugin.setEnabled(true)


func _prepare_fonts() -> void:
	bold_font = FontVariation.new()
	bold_font.base_font = ThemeDB.fallback_font
	bold_font.variation_embolden = 1.2


# -------------------- UI construction --------------------

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = COLOR_BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_top", 28)
	margin.add_theme_constant_override("margin_bottom", 20)
	add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	margin.add_child(vbox)

	var title := Label.new()
	title.text = "Taw Daw Daily"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_override("font", bold_font)
	title.add_theme_font_size_override("font_size", 26)
	title.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	vbox.add_child(title)

	# ---- Settings (gear): Title ထက်မြင့်တဲ့ App ရဲ့ ညာဘက်ထောင့်အစွန်မှာ တိုက်ရိုက်ကပ်ထား ----
	gear_btn = Button.new()
	gear_btn.custom_minimum_size = GEAR_SIZE
	gear_btn.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	gear_btn.vertical_icon_alignment = VERTICAL_ALIGNMENT_CENTER
	var gear_tex = load("res://assets/gear.svg")
	if gear_tex:
		gear_btn.icon = gear_tex
	else:
		gear_btn.text = "Menu"
	gear_btn.pressed.connect(_open_settings_menu)
	add_child(gear_btn)  # margin container ပြီးမှ ထည့်လို့ အပေါ်ဆုံးမှာ ပေါ်မယ်
	gear_btn.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 6)
	# ညာဘက်အစွန်ကို Table ဘောင် (margin 20) နဲ့ ညီအောင် ဘယ်ဘက်ကို ၁၄ px ရွှေ့
	gear_btn.offset_left -= 14.0
	gear_btn.offset_right -= 14.0
	_refresh_gear_style()

	# ---- လက်ရှိအချိန် (စက္ကန့်ပါ) - "Know your limits." နေရာ ----
	clock_label = Label.new()
	clock_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	clock_label.add_theme_font_size_override("font_size", 14)
	clock_label.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	vbox.add_child(clock_label)
	_update_clock()

	# ---- Live result panel ----
	_build_live_panel(vbox)

	# ---- လက်ရှိ ပြနေတဲ့ လ/နှစ် (ဘယ်ဘက်) + ရက်အစီအစဉ် ပြောင်းခလုတ် (ညာဘက်) ----
	var status_row := HBoxContainer.new()
	status_row.add_theme_constant_override("separation", 8)
	vbox.add_child(status_row)

	period_label = Label.new()
	period_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	period_label.add_theme_font_override("font", bold_font)
	period_label.add_theme_font_size_override("font_size", 15)
	period_label.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	period_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	status_row.add_child(period_label)

	order_btn = Button.new()
	order_btn.custom_minimum_size = Vector2(0, 30)
	order_btn.add_theme_font_size_override("font_size", 12)
	order_btn.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	order_btn.add_theme_color_override("font_hover_color", COLOR_GREEN_DARK)
	order_btn.add_theme_color_override("font_pressed_color", COLOR_GREEN_DARK)
	order_btn.add_theme_stylebox_override("normal", _chip_style(COLOR_GREEN_LIGHT))
	order_btn.add_theme_stylebox_override("hover", _chip_style(COLOR_CHIP_HOVER))
	order_btn.add_theme_stylebox_override("pressed", _chip_style(COLOR_CHIP_HOVER))
	order_btn.add_theme_stylebox_override("focus", _chip_style(COLOR_GREEN_LIGHT))
	order_btn.pressed.connect(_on_order_toggle_pressed)
	status_row.add_child(order_btn)
	_update_order_button()

	# ---- Card that holds the table ----
	var card := PanelContainer.new()
	card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var card_sb := StyleBoxFlat.new()
	card_sb.bg_color = COLOR_WHITE
	card_sb.set_corner_radius_all(20)
	card_sb.content_margin_left = 10
	card_sb.content_margin_right = 10
	card_sb.content_margin_top = 10
	card_sb.content_margin_bottom = 10
	card_sb.shadow_color = COLOR_SHADOW
	card_sb.shadow_size = 12
	card_sb.shadow_offset = Vector2(0, 4)
	card.add_theme_stylebox_override("panel", card_sb)
	vbox.add_child(card)

	var card_vbox := VBoxContainer.new()
	card_vbox.add_theme_constant_override("separation", 8)
	card.add_child(card_vbox)

	# Pinned header row (does not scroll)
	var header_margin := MarginContainer.new()
	header_margin.add_theme_constant_override("margin_right", 10)
	header_margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card_vbox.add_child(header_margin)

	header_grid = GridContainer.new()
	header_grid.columns = 4
	header_grid.add_theme_constant_override("h_separation", 4)
	header_grid.add_theme_constant_override("v_separation", 4)
	for h in SLOT_LABELS:
		header_grid.add_child(_make_cell(h, COLOR_GREEN, COLOR_ON_ACCENT, true))
	header_margin.add_child(header_grid)

	# Scrollable list of per-day entry blocks
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	card_vbox.add_child(scroll)
	table_scroll = scroll

	var entries_margin := MarginContainer.new()
	entries_margin.add_theme_constant_override("margin_right", 10)
	entries_margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(entries_margin)

	entries_vbox = VBoxContainer.new()
	entries_vbox.add_theme_constant_override("separation", 12)
	entries_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	entries_margin.add_child(entries_vbox)


# -------------------- Clock --------------------

# ဖုန်းရဲ့ လက်ရှိ (local) အချိန်၊ စက္ကန့်ပါ
func _update_clock() -> void:
	var dt: Dictionary = Time.get_datetime_dict_from_system()
	var text := "%s, %04d-%02d-%02d   %02d:%02d:%02d" % [
		str(WEEKDAY_NAMES[dt.weekday]).substr(0, 3),
		int(dt.year), int(dt.month), int(dt.day),
		int(dt.hour), int(dt.minute), int(dt.second)]
	if clock_label.text != text:
		clock_label.text = text


# -------------------- Live result panel --------------------

func _build_live_panel(parent: VBoxContainer) -> void:
	var card := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = COLOR_WHITE
	sb.set_corner_radius_all(20)
	sb.content_margin_left = 14
	sb.content_margin_right = 14
	sb.content_margin_top = 10
	sb.content_margin_bottom = 12
	sb.shadow_color = COLOR_SHADOW
	sb.shadow_size = 10
	sb.shadow_offset = Vector2(0, 3)
	card.add_theme_stylebox_override("panel", sb)
	parent.add_child(card)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 4)
	card.add_child(box)

	var top := HBoxContainer.new()
	box.add_child(top)

	var live_lbl := Label.new()
	live_lbl.text = "LIVE"
	live_lbl.add_theme_font_override("font", bold_font)
	live_lbl.add_theme_font_size_override("font_size", 13)
	live_lbl.add_theme_color_override("font_color", COLOR_ACCENT_TEXT)
	live_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(live_lbl)

	live_time_label = Label.new()
	live_time_label.add_theme_font_size_override("font_size", 11)
	live_time_label.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	top.add_child(live_time_label)

	live_content = VBoxContainer.new()
	live_content.add_theme_constant_override("separation", 2)
	live_content.custom_minimum_size = Vector2(0, 88)
	box.add_child(live_content)
	_show_live_waiting()


func _clear_live_content() -> void:
	for c in live_content.get_children():
		live_content.remove_child(c)
		c.queue_free()


# Live မလာသေးရင် (API က "--" ပေးရင်) ပြုံးနေတဲ့ မျက်နှာ
func _show_live_waiting() -> void:
	_live_signature = "waiting"
	_clear_live_content()
	live_time_label.text = ""
	var center := CenterContainer.new()
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	center.add_child(SmileyFace.new())
	live_content.add_child(center)


func _show_live_value(info: Dictionary) -> void:
	var twod := str(info.get("twod", ""))
	var set_s := str(info.get("set", ""))
	var val_s := str(info.get("val", ""))
	var time_s := str(info.get("time", ""))
	var signature := "%s|%s|%s|%s" % [twod, set_s, val_s, time_s]
	if signature == _live_signature:
		return  # မပြောင်းရင် ပြန်မဆွဲဘူး
	_live_signature = signature
	_clear_live_content()

	# "2026-11-09 11:00:05" -> "11:00:05"
	var time_parts := time_s.split(" ")
	live_time_label.text = time_parts[time_parts.size() - 1]

	var big := Label.new()
	big.text = twod
	big.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big.add_theme_font_override("font", bold_font)
	big.add_theme_font_size_override("font_size", 52)
	big.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	live_content.add_child(big)

	var mismatch := not _twod_matches(set_s, val_s, twod)
	var small := Label.new()
	small.text = "SET %s     Value %s" % [_fmt_set(set_s), _fmt_value(val_s)]
	small.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	small.add_theme_font_size_override("font_size", 12)
	small.add_theme_color_override("font_color", COLOR_WARN if mismatch else COLOR_GREEN_MUTED)
	live_content.add_child(small)


func _on_live_ready(info: Dictionary) -> void:
	_last_live = info
	var twod := str(info.get("twod", ""))
	var live_date := str(info.get("date", ""))
	# live ပါလာပေမဲ့ ရက်စွဲက ယနေ့မဟုတ်ရင် (အဟောင်း) မပြဘူး
	var fresh := (twod != "" and (live_date == "" or live_date == ApiSyncScript.thai_today()))
	if fresh:
		_show_live_value(info)
	else:
		if _live_signature != "waiting":
			_show_live_waiting()


func _on_live_timer() -> void:
	if sync != null and _is_market_hours():
		sync.fetch_live()


# ထိုင်းအချိန် တနင်္လာ–သောကြာ ၀၉:၃၀ မှ ၁၆:၅၀ အတွင်းမှာပဲ Live ကို ခဏခဏမေးတယ် (data/battery ချွေတာဖို့)
func _is_market_hours() -> bool:
	var ts: int = int(Time.get_unix_time_from_system()) + ApiSyncScript.THAI_UTC_OFFSET
	var dt: Dictionary = Time.get_datetime_dict_from_unix_time(ts)
	var wd: int = dt.weekday
	if wd == 0 or wd == 6:
		return false
	var minutes: int = int(dt.hour) * 60 + int(dt.minute)
	return minutes >= 9 * 60 + 30 and minutes <= 16 * 60 + 50


func _pill_style(color: Color, radius: int) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(radius)
	return sb


# စာလုံးအရွယ်အတိုင်း ကျုံ့တဲ့ ခလုတ်သေးလေးအတွက် (content margin ပါ)
func _chip_style(color: Color) -> StyleBoxFlat:
	var sb := _pill_style(color, 10)
	sb.content_margin_left = 10
	sb.content_margin_right = 10
	sb.content_margin_top = 4
	sb.content_margin_bottom = 4
	return sb


func _make_cell(text: String, bg_color: Color, font_color: Color, use_bold: bool) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.custom_minimum_size = Vector2(CELL_MIN_WIDTH, 0)

	var sb := StyleBoxFlat.new()
	sb.bg_color = bg_color
	sb.content_margin_left = 6
	sb.content_margin_right = 6
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	sb.set_corner_radius_all(10)
	panel.add_theme_stylebox_override("panel", sb)

	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_color_override("font_color", font_color)
	label.add_theme_font_size_override("font_size", 13)
	if use_bold:
		label.add_theme_font_override("font", bold_font)
	panel.add_child(label)
	return panel


# -------------------- Number helpers --------------------

# "1467.9" -> "1467.90"
func _fmt_set(s: String) -> String:
	if s.is_empty():
		return ""
	var parts := s.split(".")
	var dec: String = ""
	if parts.size() > 1:
		dec = parts[1]
	while dec.length() < 2:
		dec += "0"
	return "%s.%s" % [parts[0], dec]


# "34559.2" -> "34,559.2"
func _fmt_value(s: String) -> String:
	if s.is_empty():
		return ""
	var parts := s.split(".")
	var int_part: String = parts[0]
	var out := ""
	var count := 0
	for i in range(int_part.length() - 1, -1, -1):
		out = int_part[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = "," + out
	if parts.size() > 1:
		out += "." + parts[1]
	return out


# 2D = SET ရဲ့ ဒသမ ဒုတိယလုံး + Value ရဲ့ ကိန်းပြည့်အပိုင်း နောက်ဆုံးလုံး
# (တကယ့် ရလဒ် ၄ ခုနဲ့ စစ်ထားတယ်)
func _twod_matches(set_s: String, val_s: String, twod: String) -> bool:
	if not set_s.is_valid_float() or not val_s.is_valid_float():
		return true  # စစ်စရာ မရှိရင် မကိုက်ဘူးလို့ မပြဘူး
	var set_parts := set_s.split(".")
	var dec: String = ""
	if set_parts.size() > 1:
		dec = set_parts[1]
	dec += "00"
	var val_int: String = val_s.split(".")[0]
	if val_int.is_empty():
		return true
	return (dec.substr(1, 1) + val_int.right(1)) == twod


# -------------------- Table rendering --------------------

func _format_day_date(date_str: String) -> String:
	if date_str.is_empty():
		return "(no date)"
	var dt := Time.get_datetime_dict_from_datetime_string(date_str + "T00:00:00", true)
	if dt.is_empty():
		return date_str
	return "%s, %s" % [WEEKDAY_NAMES[dt.weekday], date_str]


func _small_label(text: String, color: Color) -> Label:
	var lbl := Label.new()
	lbl.text = text if text != "" else " "  # အကွက်တွေ အမြင့်တူအောင်
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.add_theme_font_size_override("font_size", 10)
	lbl.add_theme_color_override("font_color", color)
	return lbl


# 2D ကို ကြီးကြီးပြ၊ အောက်မှာ SET နဲ့ Value ကို သေးသေးပြ
func _make_result_cell(twod: String, set_s: String, val_s: String, bg_color: Color) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.custom_minimum_size = Vector2(CELL_MIN_WIDTH, 0)

	var sb := StyleBoxFlat.new()
	sb.bg_color = bg_color
	sb.content_margin_left = 3
	sb.content_margin_right = 3
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	sb.set_corner_radius_all(10)
	panel.add_theme_stylebox_override("panel", sb)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 2)
	panel.add_child(box)

	var big := Label.new()
	big.text = twod if twod != "" else "--"
	big.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big.add_theme_font_override("font", bold_font)
	big.add_theme_font_size_override("font_size", 30)
	big.add_theme_color_override("font_color", COLOR_GREEN_DARK if twod != "" else COLOR_GREEN_MUTED)
	box.add_child(big)

	var mismatch := (twod != "" and not _twod_matches(set_s, val_s, twod))
	var small_color := COLOR_WARN if mismatch else COLOR_GREEN_MUTED
	box.add_child(_small_label(_fmt_set(set_s), small_color))
	box.add_child(_small_label(_fmt_value(val_s), small_color))
	return panel


func _make_entry_block(data_index: int, alt: bool) -> VBoxContainer:
	var row: Dictionary = data[data_index]
	var block := VBoxContainer.new()
	block.add_theme_constant_override("separation", 4)

	var top_row := HBoxContainer.new()
	top_row.add_theme_constant_override("separation", 6)

	var day_lbl := Label.new()
	day_lbl.text = _format_day_date(str(row.get("date", "")))
	day_lbl.add_theme_font_size_override("font_size", 12)
	day_lbl.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	day_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top_row.add_child(day_lbl)

	if edit_mode:
		var edit_btn := Button.new()
		edit_btn.text = "✏"
		edit_btn.flat = true
		edit_btn.custom_minimum_size = Vector2(28, 28)
		edit_btn.add_theme_font_size_override("font_size", 13)
		edit_btn.pressed.connect(func(): _open_entry_dialog(data_index))
		top_row.add_child(edit_btn)

	block.add_child(top_row)

	var value_grid := GridContainer.new()
	value_grid.columns = 4
	value_grid.add_theme_constant_override("h_separation", 4)
	value_grid.add_theme_constant_override("v_separation", 4)
	var row_bg := COLOR_GREEN_LIGHT if alt else COLOR_WHITE
	for i in range(4):
		value_grid.add_child(_make_result_cell(
			str(row.get(SLOT_KEYS[i], "")),
			str(row.get(SET_KEYS[i], "")),
			str(row.get(VAL_KEYS[i], "")),
			row_bg))
	block.add_child(value_grid)

	return block


# reset_scroll = true ဆိုရင် ဇယားကို "အသစ်ဆုံးရက်" ရှိတဲ့ ဘက်ကို scroll ပြန်ရွှေ့ပေးတယ်
# (newest_first ဆို အပေါ်ဆုံး၊ မဟုတ်ရင် အောက်ဆုံး)။ Sync ကြားထဲ update တွေမှာတော့ ကိုယ် scroll လုပ်ထားတာကို မထိဘူး
func _render_table(reset_scroll: bool = false) -> void:
	for c in entries_vbox.get_children():
		c.queue_free()

	var filtered: Array = []
	for i in range(data.size()):
		var date_str := str(data[i].get("date", ""))
		if not _is_valid_date(date_str):
			continue
		var parts := date_str.split("-")
		if int(parts[0]) == filter_year and int(parts[1]) == filter_month:
			filtered.append(i)
	filtered.sort_custom(func(a, b): return str(data[a]["date"]) < str(data[b]["date"]))
	if newest_first:
		filtered.reverse()

	for pos in range(filtered.size()):
		entries_vbox.add_child(_make_entry_block(filtered[pos], pos % 2 == 0))

	if filtered.is_empty():
		var empty := Label.new()
		empty.text = "No results for this month yet."
		empty.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		empty.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
		entries_vbox.add_child(empty)

	period_label.text = "%s %d" % [MONTH_NAMES[filter_month - 1], filter_year]
	if reset_scroll:
		_apply_scroll_position()


func _apply_scroll_position() -> void:
	# Layout ပြီးဆုံးတဲ့အထိ frame နှစ်ခု စောင့်ပြီးမှ scroll ရွှေ့တယ်
	await get_tree().process_frame
	await get_tree().process_frame
	if table_scroll == null:
		return
	if newest_first:
		table_scroll.scroll_vertical = 0
	else:
		var bar: VScrollBar = table_scroll.get_v_scroll_bar()
		table_scroll.scroll_vertical = int(bar.max_value)


func _on_order_toggle_pressed() -> void:
	newest_first = !newest_first
	_update_order_button()
	_save_state()
	_render_table(true)


# ခလုတ်စာသားက အခု ပြနေတဲ့ အစီအစဉ်ကို ပြတယ်၊ နှိပ်ရင် ပြောင်းတယ်
func _update_order_button() -> void:
	order_btn.text = "Newest on top" if newest_first else "Newest at bottom"


func _on_default_pressed() -> void:
	var parts: PackedStringArray = ApiSyncScript.thai_today().split("-")
	filter_year = int(parts[0])
	filter_month = int(parts[1])
	_render_table(true)


func _on_edit_toggle_pressed() -> void:
	edit_mode = !edit_mode
	_refresh_gear_style()
	_render_table()


# The gear button turns solid green while Edit mode is on.
func _refresh_gear_style() -> void:
	var bg := COLOR_GREEN if edit_mode else COLOR_GREEN_LIGHT
	var bg_hover := COLOR_ACCENT_HOVER if edit_mode else COLOR_GREEN_LIGHT
	var icon_color := COLOR_ON_ACCENT if edit_mode else COLOR_GREEN_DARK
	gear_btn.add_theme_stylebox_override("normal", _pill_style(bg, 12))
	gear_btn.add_theme_stylebox_override("hover", _pill_style(bg_hover, 12))
	gear_btn.add_theme_stylebox_override("pressed", _pill_style(COLOR_ACCENT_HOVER, 12))
	gear_btn.add_theme_stylebox_override("focus", _pill_style(bg, 12))
	for c in ["icon_normal_color", "icon_hover_color", "icon_focus_color", "icon_pressed_color"]:
		gear_btn.add_theme_color_override(c, icon_color if c != "icon_pressed_color" else COLOR_ON_ACCENT)
	gear_btn.add_theme_color_override("font_color", icon_color)
	gear_btn.add_theme_color_override("font_hover_color", icon_color)


# -------------------- API sync --------------------

func _start_sync() -> void:
	if sync.is_busy():
		return
	var skip := {}
	for r in data:
		var row: Dictionary = r
		if _row_complete(row):
			skip[str(row.get("date", ""))] = true
	for d in checked:
		skip[d] = true
	_sync_changed_days = 0
	_show_toast("Syncing...", 0.0)
	sync.start(skip)


func _row_complete(row: Dictionary) -> bool:
	for key in SLOT_KEYS:
		if str(row.get(key, "")) == "":
			return false
	return true


func _find_index(date_str: String) -> int:
	for i in range(data.size()):
		if str(data[i].get("date", "")) == date_str:
			return i
	return -1


func _new_row(date_str: String) -> Dictionary:
	var row := {"date": date_str, "manual": []}
	for i in range(4):
		row[SLOT_KEYS[i]] = ""
		row[SET_KEYS[i]] = ""
		row[VAL_KEYS[i]] = ""
	return row


# ApiSync က ရက်တစ်ရက်စာ ယူပြီးတိုင်း ဒီကိုလာတယ်
func _on_day_ready(date: String, slots: Array, was_checked: bool) -> void:
	var any_data := false
	for s in slots:
		if str(s["twod"]) != "":
			any_data = true
	if was_checked:
		checked[date] = true
	if not any_data:
		return  # data မရှိရင် (ပိတ်ရက်) အကွက်အလွတ် မဆောက်ဘူး

	var idx := _find_index(date)
	var row: Dictionary
	var is_new := (idx < 0)
	if is_new:
		row = _new_row(date)
	else:
		row = data[idx]

	var manual: Array = []
	var m = row.get("manual", [])
	if m is Array:
		manual = m

	var changed := is_new
	for i in range(4):
		var key: String = SLOT_KEYS[i]
		if manual.has(key):
			continue  # ကိုယ်တိုင်ပြင်ထားတဲ့ အကွက်ကို မထိဘူး
		var s: Dictionary = slots[i]
		if str(s["twod"]) == "":
			continue  # server မှာ မရှိသေးတဲ့ အကွက်ကို မဖျက်ဘူး
		if str(row.get(key, "")) != str(s["twod"]) \
				or str(row.get(SET_KEYS[i], "")) != str(s["set"]) \
				or str(row.get(VAL_KEYS[i], "")) != str(s["val"]):
			row[key] = str(s["twod"])
			row[SET_KEYS[i]] = str(s["set"])
			row[VAL_KEYS[i]] = str(s["val"])
			changed = true

	if is_new:
		data.append(row)
	if changed:
		_sync_changed_days += 1
		_save_data()
		_render_table()


func _on_sync_finished(ok: bool, message: String) -> void:
	_save_data()
	_save_state()
	_render_table(not _first_sync_done)  # ပထမဆုံး sync ပြီးချိန်မှာပဲ scroll ပြန်ချိန်၊ နောက်ပိုင်း ကိုယ့်နေရာမှာ ကျန်ခဲ့
	_first_sync_done = true
	if not ok:
		_show_toast("Sync failed: %s" % message, 4.0)  # စာတိုတိုပဲ (Toast မှာ autowrap မသုံးလို့)
		return
	var text := "Up to date"
	if _sync_changed_days > 0:
		text = "Updated %d day(s)" % _sync_changed_days
	var seconds := 2.2
	if message != "":
		text += "  |  " + message  # ပုံစံမသိတာ စတဲ့ သတိပေးချက်ပါရင် ပိုကြာကြာ ပြမယ်
		seconds = 6.0
	_show_toast(text, seconds)


# -------------------- Toast (ခဏပေါ်ပြီး ပျောက်သွားတဲ့ စာတန်း) --------------------

# Screen အောက်ခြေအလယ်မှာ ပေါ်မယ်။ မထိတွေ့ရအောင် (mouse ignore) ထားတာမို့ အောက်က ဇယားကို နှိပ်လို့ရတုန်းပဲ
func _build_toast() -> void:
	var layer := MarginContainer.new()
	layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_theme_constant_override("margin_left", 24)
	layer.add_theme_constant_override("margin_right", 24)
	layer.add_theme_constant_override("margin_bottom", 30)
	add_child(layer)

	var column := VBoxContainer.new()
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(column)

	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(spacer)

	var center := CenterContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(center)

	toast_panel = PanelContainer.new()
	toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = COLOR_TOAST_BG
	sb.set_corner_radius_all(18)
	sb.content_margin_left = 16
	sb.content_margin_right = 16
	sb.content_margin_top = 9
	sb.content_margin_bottom = 9
	toast_panel.add_theme_stylebox_override("panel", sb)
	toast_panel.modulate.a = 0.0
	center.add_child(toast_panel)

	toast_label = Label.new()
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.add_theme_font_size_override("font_size", 13)
	toast_label.add_theme_color_override("font_color", COLOR_TOAST_FG)
	toast_panel.add_child(toast_label)


# seconds > 0 ဆိုရင် ထိုကြာပြီး တဖြည်းဖြည်း ပျောက်မယ်၊ 0 ဆိုရင် (Sync လုပ်နေတုန်း) နောက်စာတစ်ခု လာတဲ့အထိ ကျန်မယ်
func _show_toast(text: String, seconds: float = 2.5) -> void:
	if toast_label == null:
		return
	toast_label.text = text
	if _toast_tween != null and _toast_tween.is_valid():
		_toast_tween.kill()
	_toast_tween = create_tween()
	_toast_tween.tween_property(toast_panel, "modulate:a", 1.0, 0.15)
	if seconds > 0.0:
		_toast_tween.tween_interval(seconds)
		_toast_tween.tween_property(toast_panel, "modulate:a", 0.0, 0.35)


# -------------------- Settings menu --------------------

func _make_menu_item(text: String, filled: bool) -> Button:
	var btn := Button.new()
	btn.text = text
	btn.custom_minimum_size = Vector2(0, 44)
	btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn.add_theme_font_size_override("font_size", 15)
	var fg := COLOR_ON_ACCENT if filled else COLOR_GREEN_DARK
	var bg := COLOR_GREEN if filled else COLOR_GREEN_LIGHT
	var bg_hover := COLOR_ACCENT_HOVER if filled else COLOR_CHIP_HOVER
	btn.add_theme_color_override("font_color", fg)
	btn.add_theme_color_override("font_hover_color", fg)
	btn.add_theme_color_override("font_pressed_color", fg)
	btn.add_theme_stylebox_override("normal", _pill_style(bg, 12))
	btn.add_theme_stylebox_override("hover", _pill_style(bg_hover, 12))
	btn.add_theme_stylebox_override("pressed", _pill_style(bg_hover, 12))
	btn.add_theme_stylebox_override("focus", _pill_style(bg, 12))
	return btn


func _make_menu_heading(text: String) -> Label:
	var lbl := Label.new()
	lbl.text = text
	lbl.add_theme_font_size_override("font_size", 12)
	lbl.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	return lbl


func _open_settings_menu() -> void:
	var built := _make_overlay_card(280)
	var overlay: ColorRect = built["overlay"]
	var outer: VBoxContainer = built["outer"]
	outer.add_theme_constant_override("separation", 10)

	# Tapping the dimmed area outside the card closes the menu.
	overlay.gui_input.connect(func(event: InputEvent):
		if event is InputEventMouseButton and event.is_pressed():
			overlay.queue_free()
	)

	_make_title_row(outer, "Settings", func(): overlay.queue_free())

	# Landscape မှာ menu အရှည်ကြီးကို scroll လုပ်လို့ရအောင်
	var body := _make_scroll_body(outer, 500)

	body.add_child(_make_menu_heading("View"))

	var today_btn := _make_menu_item("Today", false)
	today_btn.pressed.connect(func():
		overlay.queue_free()
		_on_default_pressed()
	)
	body.add_child(today_btn)

	var edit_btn := _make_menu_item("Done editing" if edit_mode else "Edit entries", edit_mode)
	edit_btn.pressed.connect(func():
		overlay.queue_free()
		_on_edit_toggle_pressed()
	)
	body.add_child(edit_btn)

	var sort_btn := _make_menu_item("Sort (Month / Year)", false)
	sort_btn.pressed.connect(func():
		overlay.queue_free()
		_open_sort_dialog()
	)
	body.add_child(sort_btn)

	var theme_btn := _make_menu_item("Theme (Color / Dark mode)", false)
	theme_btn.pressed.connect(func():
		overlay.queue_free()
		_open_theme_dialog()
	)
	body.add_child(theme_btn)

	var calc_btn := _make_menu_item("Formula table", false)
	calc_btn.pressed.connect(func():
		overlay.queue_free()
		_open_calc_screen()
	)
	body.add_child(calc_btn)

	body.add_child(_make_menu_heading("Data"))

	# Main screen ကနေ "Add New" ခလုတ်ကို ဖယ်ထားလို့ ကိုယ်တိုင်ထည့်ချင်ရင် ဒီကနေ
	var add_item := _make_menu_item("Add entry (manual)", false)
	add_item.pressed.connect(func():
		overlay.queue_free()
		_open_entry_dialog(-1)
	)
	body.add_child(add_item)

	var sync_btn := _make_menu_item("Sync now", false)
	sync_btn.pressed.connect(func():
		overlay.queue_free()
		_start_sync()
	)
	body.add_child(sync_btn)

	if notify_plugin != null:
		var notify_on: bool = bool(notify_plugin.isEnabled())
		var notify_btn := _make_menu_item("Result notifications: " + ("ON" if notify_on else "OFF"), false)
		notify_btn.pressed.connect(func():
			overlay.queue_free()
			notify_plugin.setEnabled(not notify_on)
			if notify_on:
				_show_toast("Notifications off")
			elif bool(notify_plugin.canExactAlarm()):
				_show_toast("Notifications on")
			else:
				_show_toast("Notifications on (time may be a bit late)", 4.0)
		)
		body.add_child(notify_btn)

		var notify_info_btn := _make_menu_item("Notification status / test", false)
		notify_info_btn.pressed.connect(func():
			overlay.queue_free()
			_open_notify_dialog()
		)
		body.add_child(notify_info_btn)

	body.add_child(_make_menu_heading("Backup"))

	var import_btn := _make_menu_item("Import Backup (.json)", false)
	import_btn.pressed.connect(func():
		overlay.queue_free()
		_pick_file(false, _import_backup_from)
	)
	body.add_child(import_btn)

	var export_btn := _make_menu_item("Export Backup (.json)", false)
	export_btn.pressed.connect(func():
		overlay.queue_free()
		_pick_file(true, _export_backup_to)
	)
	body.add_child(export_btn)

	var exit_btn := _make_menu_item("Exit App", true)
	exit_btn.pressed.connect(func(): get_tree().quit())
	body.add_child(exit_btn)


# -------------------- Backup: import / export --------------------

# Opens the system file picker (Android မှာ System Document Picker၊ Permission မလို)
func _pick_file(for_saving: bool, on_picked: Callable) -> void:
	var dlg := FileDialog.new()
	dlg.access = FileDialog.ACCESS_FILESYSTEM
	dlg.use_native_dialog = true
	dlg.file_mode = FileDialog.FILE_MODE_SAVE_FILE if for_saving else FileDialog.FILE_MODE_OPEN_FILE
	dlg.filters = PackedStringArray(["*.json ; JSON backup"])
	if for_saving:
		dlg.current_file = "taw_daw_daily_backup_%s.json" % Time.get_date_string_from_system()
	dlg.file_selected.connect(func(path: String):
		on_picked.call(path)
		dlg.queue_free()
	)
	dlg.canceled.connect(func(): dlg.queue_free())
	add_child(dlg)
	dlg.popup_centered_ratio(0.9)


func _export_backup_to(path: String) -> void:
	var text := JSON.stringify(data, "\t")
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		var err := FileAccess.get_open_error()
		var fallback := OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS).path_join(path.get_file())
		file = FileAccess.open(fallback, FileAccess.WRITE)
		if file == null:
			_show_message("Export failed", "Could not write the backup file (error %d)." % err)
			return
		path = fallback
	file.store_string(text)
	file.close()
	_show_message("Backup saved", "%d entries saved to:\n%s" % [data.size(), path])


# ရက်စွဲတူရင် Backup ထဲမှာ ပါတဲ့ field တွေပဲ ပြောင်းတယ် (မပါတဲ့ field ကို မဖျက်ဘူး)
# ဒါကြောင့် Taw Daw Calendar ရဲ့ backup (slot1..slot4 ပဲပါ) ကိုလည်း import လုပ်လို့ရတယ်
func _import_backup_from(path: String) -> void:
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		_show_message("Import failed", "Could not open the selected file (error %d)." % FileAccess.get_open_error())
		return
	var text := file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(text)
	if typeof(parsed) != TYPE_ARRAY:
		_show_message("Import failed", "This is not a valid Taw Daw backup file.")
		return

	var index_by_date := {}
	for i in range(data.size()):
		index_by_date[str(data[i].get("date", ""))] = i

	var added := 0
	var updated := 0
	var skipped := 0
	var value_keys: Array = SLOT_KEYS + SET_KEYS + VAL_KEYS
	for item in parsed:
		if typeof(item) != TYPE_DICTIONARY:
			skipped += 1
			continue
		var date_str := str(item.get("date", "")).strip_edges()
		if not _is_valid_date(date_str):
			skipped += 1
			continue

		var row: Dictionary
		var existing := index_by_date.has(date_str)
		if existing:
			row = data[index_by_date[date_str]].duplicate(true)
		else:
			row = _new_row(date_str)
		for key in value_keys:
			if item.has(key):
				row[key] = str(item[key]).strip_edges()
		if item.has("manual") and item["manual"] is Array:
			var m: Array = []
			for k in item["manual"]:
				if SLOT_KEYS.has(str(k)):
					m.append(str(k))
			row["manual"] = m

		if existing:
			data[index_by_date[date_str]] = row
			updated += 1
		else:
			data.append(row)
			index_by_date[date_str] = data.size() - 1
			added += 1

	_save_data()
	_render_table()
	var summary := "%d added, %d updated" % [added, updated]
	if skipped > 0:
		summary += ", %d skipped (invalid)" % skipped
	_show_message("Import complete", summary)


func _show_message(title_text: String, body: String) -> void:
	var built := _make_overlay_card(280)
	var overlay: ColorRect = built["overlay"]
	var outer: VBoxContainer = built["outer"]

	_make_title_row(outer, title_text, func(): overlay.queue_free())

	var lbl := Label.new()
	lbl.text = body
	lbl.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	lbl.custom_minimum_size = Vector2(240, 0)
	lbl.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	outer.add_child(lbl)

	var ok_btn := _make_confirm_button("OK")
	ok_btn.pressed.connect(func(): overlay.queue_free())
	outer.add_child(ok_btn)


# -------------------- Shared modal helpers --------------------

func _styled_line_edit() -> LineEdit:
	var edit := LineEdit.new()
	edit.placeholder_text = "Enter value"
	edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	edit.custom_minimum_size = Vector2(0, 40)

	var normal_sb := StyleBoxFlat.new()
	normal_sb.bg_color = COLOR_GREEN_LIGHT
	normal_sb.set_corner_radius_all(10)
	normal_sb.content_margin_left = 10
	normal_sb.content_margin_right = 10
	var focus_sb := normal_sb.duplicate()
	focus_sb.border_width_bottom = 2
	focus_sb.border_color = COLOR_GREEN
	edit.add_theme_stylebox_override("normal", normal_sb)
	edit.add_theme_stylebox_override("focus", focus_sb)
	edit.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	edit.add_theme_color_override("font_placeholder_color", COLOR_GREEN_MUTED)
	edit.add_theme_color_override("caret_color", COLOR_GREEN_DARK)
	return edit


# ဂဏန်းသီးသန့် (allow_dot ဆိုရင် "." ပါ ခွင့်ပြု)
func _make_numeric_edit(placeholder: String, max_len: int, allow_dot: bool) -> LineEdit:
	var edit := _styled_line_edit()
	edit.placeholder_text = placeholder
	edit.max_length = max_len
	edit.text_changed.connect(func(new_text: String):
		var filtered := ""
		var dot_seen := false
		for c in new_text:
			if c.is_valid_int():
				filtered += c
			elif allow_dot and c == "." and not dot_seen:
				filtered += c
				dot_seen = true
		if filtered != new_text:
			edit.text = filtered
			edit.caret_column = filtered.length()
	)
	return edit


func _make_overlay_card(min_width: int) -> Dictionary:
	var overlay := ColorRect.new()
	overlay.color = COLOR_DIM
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(overlay)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)

	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(min_width, 0)
	card.mouse_filter = Control.MOUSE_FILTER_STOP
	var card_sb := StyleBoxFlat.new()
	card_sb.bg_color = COLOR_WHITE
	card_sb.set_corner_radius_all(20)
	card_sb.content_margin_left = 20
	card_sb.content_margin_right = 20
	card_sb.content_margin_top = 18
	card_sb.content_margin_bottom = 20
	card_sb.shadow_color = Color(0.08, 0.20, 0.11, 0.35)
	card_sb.shadow_size = 16
	card.add_theme_stylebox_override("panel", card_sb)
	center.add_child(card)

	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 16)
	card.add_child(outer)

	return {"overlay": overlay, "outer": outer}


# Card ထဲမှာ scroll လုပ်လို့ရတဲ့ body တစ်ခု ထည့်ပေးတယ်။ Screen နိမ့်ရင် (Landscape)
# အမြင့်ကို screen ရဲ့ ၆၀% အထိပဲ ကန့်သတ်တယ်။
func _make_scroll_body(outer: VBoxContainer, desired_height: float) -> VBoxContainer:
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.custom_minimum_size = Vector2(0, minf(desired_height, get_viewport_rect().size.y * 0.6))
	outer.add_child(scroll)

	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 10)
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(body)
	return body


func _make_title_row(outer: VBoxContainer, title_text: String, on_close: Callable) -> void:
	var title_row := HBoxContainer.new()
	outer.add_child(title_row)

	var title_lbl := Label.new()
	title_lbl.text = title_text
	title_lbl.add_theme_font_override("font", bold_font)
	title_lbl.add_theme_font_size_override("font_size", 18)
	title_lbl.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_row.add_child(title_lbl)

	var close_btn := Button.new()
	close_btn.text = "✕"
	close_btn.flat = true
	close_btn.custom_minimum_size = Vector2(30, 30)
	close_btn.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	close_btn.add_theme_color_override("font_hover_color", COLOR_GREEN_DARK)
	close_btn.pressed.connect(on_close)
	title_row.add_child(close_btn)


func _make_confirm_button(text: String) -> Button:
	var btn := Button.new()
	btn.text = text
	btn.custom_minimum_size = Vector2(0, 48)
	btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn.add_theme_font_override("font", bold_font)
	btn.add_theme_font_size_override("font_size", 16)
	btn.add_theme_color_override("font_color", COLOR_ON_ACCENT)
	btn.add_theme_color_override("font_hover_color", COLOR_ON_ACCENT)
	btn.add_theme_color_override("font_pressed_color", COLOR_ON_ACCENT)
	btn.add_theme_stylebox_override("normal", _pill_style(COLOR_GREEN, 12))
	btn.add_theme_stylebox_override("hover", _pill_style(COLOR_ACCENT_HOVER, 12))
	btn.add_theme_stylebox_override("pressed", _pill_style(COLOR_ACCENT_HOVER, 12))
	return btn


func _is_valid_date(s: String) -> bool:
	var re := RegEx.new()
	re.compile("^\\d{4}-\\d{2}-\\d{2}$")
	if re.search(s) == null:
		return false
	var parts := s.split("-")
	var m := int(parts[1])
	var d := int(parts[2])
	return m >= 1 and m <= 12 and d >= 1 and d <= 31


# -------------------- Add / Edit entry dialog --------------------

func _open_entry_dialog(existing_index: int) -> void:
	var is_edit := existing_index >= 0
	var old_row: Dictionary = {}
	if is_edit:
		old_row = data[existing_index]
	var init_date := str(old_row.get("date", ApiSyncScript.thai_today()))

	var built := _make_overlay_card(340)
	var overlay: ColorRect = built["overlay"]
	var outer: VBoxContainer = built["outer"]

	_make_title_row(outer, "Edit Results" if is_edit else "Add Results", func(): overlay.queue_free())

	# Date + အကွက် ၄ ခုက scroll လုပ်လို့ရတဲ့ body ထဲ၊ Update ခလုတ်က အောက်မှာ အမြဲမြင်ရမယ်
	var body := _make_scroll_body(outer, 420)

	var date_row := HBoxContainer.new()
	date_row.add_theme_constant_override("separation", 10)
	var date_lbl := Label.new()
	date_lbl.text = "Date"
	date_lbl.custom_minimum_size = Vector2(50, 0)
	date_lbl.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	date_row.add_child(date_lbl)
	var date_edit := _styled_line_edit()
	date_edit.placeholder_text = "YYYY-MM-DD"
	date_edit.text = init_date
	date_row.add_child(date_edit)
	body.add_child(date_row)

	# slot_edits[i] = [2D, SET, Value] LineEdit သုံးခု
	var slot_edits: Array = []
	for i in range(4):
		var slot_lbl := Label.new()
		slot_lbl.text = SLOT_LABELS[i]
		slot_lbl.add_theme_font_override("font", bold_font)
		slot_lbl.add_theme_font_size_override("font_size", 13)
		slot_lbl.add_theme_color_override("font_color", COLOR_ACCENT_TEXT)
		body.add_child(slot_lbl)

		var line := HBoxContainer.new()
		line.add_theme_constant_override("separation", 6)

		var twod_edit := _make_numeric_edit("2D", 2, false)
		twod_edit.size_flags_horizontal = Control.SIZE_FILL
		twod_edit.custom_minimum_size = Vector2(56, 40)
		twod_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
		twod_edit.text = str(old_row.get(SLOT_KEYS[i], ""))
		line.add_child(twod_edit)

		var set_edit := _make_numeric_edit("SET", 12, true)
		set_edit.text = str(old_row.get(SET_KEYS[i], ""))
		line.add_child(set_edit)

		var val_edit := _make_numeric_edit("Value", 14, true)
		val_edit.text = str(old_row.get(VAL_KEYS[i], ""))
		line.add_child(val_edit)

		body.add_child(line)
		slot_edits.append([twod_edit, set_edit, val_edit])

	var hint := Label.new()
	hint.text = "Fields you change are kept as your own. Clear a slot to let the server fill it again."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size", 11)
	hint.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	body.add_child(hint)

	var update_btn := _make_confirm_button("Update")
	update_btn.pressed.connect(func():
		var date_str: String = date_edit.text.strip_edges()
		if not _is_valid_date(date_str):
			_show_message("Invalid date", "Please use YYYY-MM-DD, for example 2026-11-06.")
			return
		var found := _find_index(date_str)
		if is_edit and found >= 0 and found != existing_index:
			_show_message("Date already exists", "%s already has an entry. Edit that entry instead." % date_str)
			return

		# Add New ပေမဲ့ ရက်စွဲရှိပြီးသားဆိုရင် အဲဒီ entry ကိုပဲ update လုပ်တယ် (ထပ်မနေအောင်)
		var target := existing_index if is_edit else found
		var prev: Dictionary = {}
		if target >= 0:
			prev = data[target]

		var manual: Array = []
		var prev_manual = prev.get("manual", [])
		if prev_manual is Array:
			manual = prev_manual.duplicate()

		var new_row := _new_row(date_str)
		for i in range(4):
			var e: Array = slot_edits[i]
			var t: String = e[0].text.strip_edges()
			if t.length() == 1:
				t = t.pad_zeros(2)
			var s: String = e[1].text.strip_edges()
			var v: String = e[2].text.strip_edges()
			new_row[SLOT_KEYS[i]] = t
			new_row[SET_KEYS[i]] = s
			new_row[VAL_KEYS[i]] = v

			var key: String = SLOT_KEYS[i]
			var is_empty := (t == "" and s == "" and v == "")
			var is_changed := (t != str(prev.get(SLOT_KEYS[i], "")) \
				or s != str(prev.get(SET_KEYS[i], "")) \
				or v != str(prev.get(VAL_KEYS[i], "")))
			if is_empty:
				manual.erase(key)
			elif is_changed and not manual.has(key):
				manual.append(key)
		new_row["manual"] = manual

		if target >= 0:
			data[target] = new_row
		else:
			data.append(new_row)
		_save_data()

		# ပြင်လိုက်တဲ့ ရက်က တခြားလထဲမှာဆိုရင် အဲဒီလကို သွားပြမယ်
		var dparts := date_str.split("-")
		filter_year = int(dparts[0])
		filter_month = clampi(int(dparts[1]), 1, 12)
		_render_table()
		overlay.queue_free()
	)
	outer.add_child(update_btn)


# -------------------- Sort (month/year picker) dialog --------------------

func _open_sort_dialog() -> void:
	var built := _make_overlay_card(300)
	var overlay: ColorRect = built["overlay"]
	var outer: VBoxContainer = built["outer"]

	_make_title_row(outer, "Select Month & Year", func(): overlay.queue_free())

	var pending := {"month": filter_month, "year": filter_year}

	# Year range: data ထဲက နှစ်အားလုံး + ယခုနှစ်ရဲ့ နောက်/ရှေ့ နည်းနည်း
	var today_year := int(ApiSyncScript.thai_today().split("-")[0])
	var min_year: int = today_year - 3
	var max_year: int = today_year + 1
	for row in data:
		var date_str := str(row.get("date", ""))
		if not _is_valid_date(date_str):
			continue
		var y := int(date_str.split("-")[0])
		min_year = min(min_year, y)
		max_year = max(max_year, y)
	min_year = min(min_year, filter_year)
	max_year = max(max_year, filter_year)

	var picker_row := HBoxContainer.new()
	picker_row.add_theme_constant_override("separation", 14)
	outer.add_child(picker_row)

	var month_btns: Array = []
	var year_btns: Array = []

	var month_col := _build_picker_column("Month", picker_row)
	for m in range(1, 13):
		var btn := _make_picker_item_button(MONTH_NAMES[m - 1].substr(0, 3), m == pending.month)
		btn.pressed.connect(func():
			pending.month = m
			for b in month_btns:
				_set_picker_selected(b["button"], b["value"] == pending.month)
		)
		month_col.add_child(btn)
		month_btns.append({"button": btn, "value": m})

	var year_col := _build_picker_column("Year", picker_row)
	for y2 in range(min_year, max_year + 1):
		var btn2 := _make_picker_item_button(str(y2), y2 == pending.year)
		btn2.pressed.connect(func():
			pending.year = y2
			for b in year_btns:
				_set_picker_selected(b["button"], b["value"] == pending.year)
		)
		year_col.add_child(btn2)
		year_btns.append({"button": btn2, "value": y2})

	var ok_btn := _make_confirm_button("OK")
	ok_btn.pressed.connect(func():
		filter_month = pending.month
		filter_year = pending.year
		_render_table(true)
		overlay.queue_free()
	)
	outer.add_child(ok_btn)


func _build_picker_column(heading: String, parent: HBoxContainer) -> VBoxContainer:
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(col)

	var heading_lbl := Label.new()
	heading_lbl.text = heading
	heading_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading_lbl.add_theme_font_size_override("font_size", 12)
	heading_lbl.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	col.add_child(heading_lbl)

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, minf(160.0, get_viewport_rect().size.y * 0.35))
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(scroll)

	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 4)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)

	return list


func _make_picker_item_button(text: String, selected: bool) -> Button:
	var btn := Button.new()
	btn.text = text
	btn.custom_minimum_size = Vector2(0, 34)
	btn.add_theme_font_size_override("font_size", 13)
	_set_picker_selected(btn, selected)
	return btn


func _set_picker_selected(btn: Button, selected: bool) -> void:
	if selected:
		btn.add_theme_color_override("font_color", COLOR_ON_ACCENT)
		btn.add_theme_color_override("font_hover_color", COLOR_ON_ACCENT)
		btn.add_theme_stylebox_override("normal", _pill_style(COLOR_GREEN, 8))
		btn.add_theme_stylebox_override("hover", _pill_style(COLOR_ACCENT_HOVER, 8))
	else:
		btn.add_theme_color_override("font_color", COLOR_GREEN_DARK)
		btn.add_theme_color_override("font_hover_color", COLOR_GREEN_DARK)
		btn.add_theme_stylebox_override("normal", _pill_style(COLOR_GREEN_LIGHT, 8))
		btn.add_theme_stylebox_override("hover", _pill_style(COLOR_GREEN_LIGHT, 8))


# -------------------- Formula table (Excel "For Taw Daw" Sheet) --------------------

# row -> DayCalc.compute() ရလဒ်။ 12:00 နဲ့ 16:30 နံပါတ် ၂ လုံးတွဲ မပြည့်သေးရင် {}
func _calc_for_row(row: Dictionary) -> Dictionary:
	return DayCalcScript.compute(
		str(row.get("slot2", "")).strip_edges(),
		str(row.get("slot4", "")).strip_edges())


# A17 ကို ဇယားထဲမှာ ပြဖို့ အတိုချုပ်။ BK ဆိုရင် "A 7 · B 72.05 · C 72.94 (BK)"
func _calc_result_text(a17: String) -> String:
	if DayCalcScript.is_plain_pair(a17):
		return a17
	return a17.replace("A = ", "A ").replace(", B = ", "  ·  B ").replace(", C = ", "  ·  C ")


func _calc_cell_label(text: String, color: Color, font_size: int, bold: bool, ratio: float) -> Label:
	var lbl := Label.new()
	lbl.text = text
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lbl.size_flags_vertical = Control.SIZE_EXPAND_FILL
	lbl.size_flags_stretch_ratio = ratio
	lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl.custom_minimum_size = Vector2(10, 0)
	lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	lbl.add_theme_font_size_override("font_size", font_size)
	lbl.add_theme_color_override("font_color", color)
	if bold:
		lbl.add_theme_font_override("font", bold_font)
	return lbl


func _open_calc_screen() -> void:
	var overlay := Control.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(overlay)

	var bg := ColorRect.new()
	bg.color = COLOR_BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_top", 28)
	margin.add_theme_constant_override("margin_bottom", 20)
	overlay.add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	margin.add_child(vbox)

	# ---- အပေါ်ဆုံး: Back + ခေါင်းစီး ----
	var top := HBoxContainer.new()
	vbox.add_child(top)
	var back_btn := _make_menu_item("‹ Back", false)
	back_btn.custom_minimum_size = Vector2(84, 40)
	back_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	back_btn.pressed.connect(func(): overlay.queue_free())
	top.add_child(back_btn)
	var title := Label.new()
	title.text = "Formula table"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_font_override("font", bold_font)
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	top.add_child(title)
	var top_pad := Control.new()
	top_pad.custom_minimum_size = Vector2(84, 0)
	top.add_child(top_pad)

	# ---- လ ရွေးတဲ့ အတန်း (ဒီစာမျက်နှာကိုယ်ပိုင်၊ main table ကို မထိ) ----
	var view := {"y": filter_year, "m": filter_month}
	var nav := HBoxContainer.new()
	nav.add_theme_constant_override("separation", 8)
	vbox.add_child(nav)
	var prev_btn := _make_menu_item("‹", false)
	prev_btn.custom_minimum_size = Vector2(52, 38)
	nav.add_child(prev_btn)
	var month_label := Label.new()
	month_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	month_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	month_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	month_label.add_theme_font_override("font", bold_font)
	month_label.add_theme_font_size_override("font_size", 15)
	month_label.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	nav.add_child(month_label)
	var next_btn := _make_menu_item("›", false)
	next_btn.custom_minimum_size = Vector2(52, 38)
	nav.add_child(next_btn)

	var hint := Label.new()
	hint.text = "Prediction (A17) from each day's 12:00 and 4:30 numbers. Tap a row for the full calculation."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size", 11)
	hint.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	vbox.add_child(hint)

	# ---- ဇယား card ----
	var card := PanelContainer.new()
	card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var card_sb := StyleBoxFlat.new()
	card_sb.bg_color = COLOR_WHITE
	card_sb.set_corner_radius_all(20)
	card_sb.content_margin_left = 10
	card_sb.content_margin_right = 10
	card_sb.content_margin_top = 10
	card_sb.content_margin_bottom = 10
	card_sb.shadow_color = COLOR_SHADOW
	card_sb.shadow_size = 12
	card_sb.shadow_offset = Vector2(0, 4)
	card.add_theme_stylebox_override("panel", card_sb)
	vbox.add_child(card)

	var card_vbox := VBoxContainer.new()
	card_vbox.add_theme_constant_override("separation", 8)
	card.add_child(card_vbox)

	var header_margin := MarginContainer.new()
	header_margin.add_theme_constant_override("margin_right", 10)
	card_vbox.add_child(header_margin)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 4)
	header_margin.add_child(header)
	var h_date := _make_cell("Date", COLOR_GREEN, COLOR_ON_ACCENT, true)
	h_date.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h_date.size_flags_stretch_ratio = 1.0
	header.add_child(h_date)
	var h_pred := _make_cell("Prediction", COLOR_GREEN, COLOR_ON_ACCENT, true)
	h_pred.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h_pred.size_flags_stretch_ratio = 2.4
	header.add_child(h_pred)

	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	card_vbox.add_child(scroll)
	var list_margin := MarginContainer.new()
	list_margin.add_theme_constant_override("margin_right", 10)
	list_margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list_margin)
	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 6)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_margin.add_child(list)

	prev_btn.pressed.connect(func():
		view["m"] = int(view["m"]) - 1
		if int(view["m"]) < 1:
			view["m"] = 12
			view["y"] = int(view["y"]) - 1
		_fill_calc_list(list, month_label, view)
	)
	next_btn.pressed.connect(func():
		view["m"] = int(view["m"]) + 1
		if int(view["m"]) > 12:
			view["m"] = 1
			view["y"] = int(view["y"]) + 1
		_fill_calc_list(list, month_label, view)
	)
	_fill_calc_list(list, month_label, view)


func _fill_calc_list(list: VBoxContainer, month_label: Label, view: Dictionary) -> void:
	for c in list.get_children():
		list.remove_child(c)
		c.queue_free()
	month_label.text = "%s %d" % [MONTH_NAMES[int(view["m"]) - 1], int(view["y"])]

	var filtered: Array = []
	for i in range(data.size()):
		var date_str := str(data[i].get("date", ""))
		if not _is_valid_date(date_str):
			continue
		var parts := date_str.split("-")
		if int(parts[0]) == int(view["y"]) and int(parts[1]) == int(view["m"]):
			filtered.append(i)
	filtered.sort_custom(func(a, b): return str(data[a]["date"]) < str(data[b]["date"]))
	if newest_first:
		filtered.reverse()

	for pos in range(filtered.size()):
		list.add_child(_make_calc_row(int(filtered[pos]), pos % 2 == 0))

	if filtered.is_empty():
		var empty := Label.new()
		empty.text = "No results for this month yet."
		empty.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		empty.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
		list.add_child(empty)


func _make_calc_row(data_index: int, alt: bool) -> Button:
	var row: Dictionary = data[data_index]
	var res: Dictionary = _calc_for_row(row)

	var btn := Button.new()
	btn.custom_minimum_size = Vector2(0, 50)
	btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var row_bg := COLOR_GREEN_LIGHT if alt else COLOR_WHITE
	btn.add_theme_stylebox_override("normal", _pill_style(row_bg, 10))
	btn.add_theme_stylebox_override("hover", _pill_style(COLOR_CHIP_HOVER, 10))
	btn.add_theme_stylebox_override("pressed", _pill_style(COLOR_CHIP_HOVER, 10))
	btn.add_theme_stylebox_override("focus", _pill_style(row_bg, 10))
	btn.pressed.connect(func(): _open_calc_detail(data_index))

	var hb := HBoxContainer.new()
	hb.set_anchors_preset(Control.PRESET_FULL_RECT)
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_theme_constant_override("separation", 4)
	btn.add_child(hb)

	var date_str := str(row.get("date", ""))
	var weekday := _format_day_date(date_str).split(",")[0].substr(0, 3)
	hb.add_child(_calc_cell_label("%s\n%s" % [date_str.substr(5), weekday], COLOR_GREEN_MUTED, 12, false, 1.0))

	if res.is_empty():
		hb.add_child(_calc_cell_label("—", COLOR_GREEN_MUTED, 14, false, 2.4))
	else:
		var a17 := str(res["a17"])
		if DayCalcScript.is_plain_pair(a17):
			hb.add_child(_calc_cell_label(a17, COLOR_ACCENT_TEXT, 26, true, 2.4))
		else:
			hb.add_child(_calc_cell_label(_calc_result_text(a17), COLOR_ACCENT_TEXT, 13, true, 2.4))
	return btn


func _calc_add_line(grid: GridContainer, name_text: String, value_text: String) -> void:
	var n := Label.new()
	n.text = name_text
	n.custom_minimum_size = Vector2(92, 0)
	n.add_theme_font_size_override("font_size", 11)
	n.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	grid.add_child(n)
	var v := Label.new()
	v.text = value_text
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.custom_minimum_size = Vector2(10, 0)
	v.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	v.add_theme_font_size_override("font_size", 13)
	v.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	grid.add_child(v)


# Excel ရဲ့ cell အားလုံးကို ဖော်ပြတယ် (r = DayCalc.compute() ရလဒ်)
func _fill_calc_values(vals: VBoxContainer, r: Dictionary) -> void:
	var a17 := str(r["a17"])
	var big := Label.new()
	big.text = a17 if DayCalcScript.is_plain_pair(a17) else _calc_result_text(a17)
	big.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	big.add_theme_font_override("font", bold_font)
	big.add_theme_font_size_override("font_size", 44 if DayCalcScript.is_plain_pair(a17) else 20)
	big.add_theme_color_override("font_color", COLOR_ACCENT_TEXT)
	vals.add_child(big)
	var cap := Label.new()
	cap.text = "A17 · A = Tomorrow" if DayCalcScript.is_plain_pair(a17) else "A17 · Keybreak (BK)"
	cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cap.add_theme_font_size_override("font_size", 12)
	cap.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	vals.add_child(cap)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 6)
	vals.add_child(grid)

	var blue := str(r["blue"])
	var green := str(r["green"])
	var a7 := str(r["a7"])
	var e7 := str(r["e7"])
	_calc_add_line(grid, "A4 C4 E4 G4", "%d  %d  %d  %d" % [r["a4"], r["c4"], r["e4"], r["g4"]])
	_calc_add_line(grid, "A5 C5 E5 G5", "%d  %d  %d  %d" % [r["a5"], r["c5"], r["e5"], r["g5"]])
	_calc_add_line(grid, "A6  π×A5C5E5G5", DayCalcScript.excel_text(float(r["a6"])))
	_calc_add_line(grid, "E6  π×A4C4E4G4", DayCalcScript.excel_text(float(r["e6"])))
	_calc_add_line(grid, "A7  (A5C5E5G5)", a7 if a7 == blue else "%s  →  %s" % [blue, a7])
	_calc_add_line(grid, "E7  (A4C4E4G4)", e7 if e7 == green else "%s  →  %s" % [green, e7])
	_calc_add_line(grid, "A8  π×A7", DayCalcScript.excel_text(float(r["a8"])))
	_calc_add_line(grid, "E8  π×E7", DayCalcScript.excel_text(float(r["e8"])))
	_calc_add_line(grid, "A9  e×A5C5E5G5", DayCalcScript.excel_text(float(r["a9"])))
	_calc_add_line(grid, "E9  e×A4C4E4G4", DayCalcScript.excel_text(float(r["e9"])))
	_calc_add_line(grid, "A10  e×A7", DayCalcScript.excel_text(float(r["a10"])))
	_calc_add_line(grid, "E10  e×E7", DayCalcScript.excel_text(float(r["e10"])))
	_calc_add_line(grid, "A11", str(r["a11"]))
	_calc_add_line(grid, "E11", str(r["e11"]))
	_calc_add_line(grid, "A12", str(r["a12"]))
	_calc_add_line(grid, "E12", str(r["e12"]))
	_calc_add_line(grid, "A13", str(r["a13"]))
	_calc_add_line(grid, "A14", str(r["a14"]))
	_calc_add_line(grid, "C14", str(r["c14"]))
	_calc_add_line(grid, "E14", str(r["e14"]))
	_calc_add_line(grid, "G14", str(r["g14"]))
	_calc_add_line(grid, "A15", str(r["a15"]))
	_calc_add_line(grid, "A16", str(r["a16"]))
	_calc_add_line(grid, "E16", str(r["e16"]))
	_calc_add_line(grid, "A17", a17)

	var note := Label.new()
	note.text = "A = Tomorrow, B/C = Every Other Day (If A fails)\nA7 / E7: repeated digits are replaced by the fixed table (e.g. 1886 → 1836)."
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.add_theme_font_size_override("font_size", 11)
	note.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	vals.add_child(note)


func _open_calc_detail(data_index: int) -> void:
	var row: Dictionary = data[data_index]
	var s2 := str(row.get("slot2", "")).strip_edges()
	var s4 := str(row.get("slot4", "")).strip_edges()

	var built := _make_overlay_card(340)
	var overlay: ColorRect = built["overlay"]
	var outer: VBoxContainer = built["outer"]
	_make_title_row(outer, _format_day_date(str(row.get("date", ""))), func(): overlay.queue_free())

	var body := _make_scroll_body(outer, 480.0)

	# ရက်တစ်ရက်စာ နံပါတ် ၄ ခု (Excel ရဲ့ row 2-3)
	var inputs := Label.new()
	var parts: PackedStringArray = PackedStringArray()
	for i in range(4):
		var n := str(row.get(SLOT_KEYS[i], "")).strip_edges()
		parts.append("%s  %s" % [SLOT_LABELS[i], n if n != "" else "--"])
	inputs.text = "   ".join(parts)
	inputs.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	inputs.add_theme_font_size_override("font_size", 12)
	inputs.add_theme_color_override("font_color", COLOR_GREEN_MUTED)
	body.add_child(inputs)

	var r: Dictionary = DayCalcScript.compute(s2, s4)
	if r.is_empty():
		var warn := Label.new()
		warn.text = "The formulas need both the 12:00 PM and 4:30 PM numbers (2 digits each). Add them first."
		warn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		warn.add_theme_font_size_override("font_size", 13)
		warn.add_theme_color_override("font_color", COLOR_WARN)
		body.add_child(warn)
		return

	var vals := VBoxContainer.new()
	vals.add_theme_constant_override("separation", 8)
	body.add_child(vals)
	_fill_calc_values(vals, r)


# -------------------- Notification status / test --------------------

func _open_notify_dialog() -> void:
	if notify_plugin == null:
		return
	var built := _make_overlay_card(320)
	var overlay: ColorRect = built["overlay"]
	var outer: VBoxContainer = built["outer"]
	_make_title_row(outer, "Notification status", func(): overlay.queue_free())

	var body := _make_scroll_body(outer, 300.0)
	var info := Label.new()
	info.text = str(notify_plugin.getStatus())
	info.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.add_theme_font_size_override("font_size", 12)
	info.add_theme_color_override("font_color", COLOR_GREEN_DARK)
	body.add_child(info)

	var test_btn := _make_menu_item("Send test notification", true)
	test_btn.pressed.connect(func():
		notify_plugin.testNotify()
		_show_toast("Test notification sent")
	)
	outer.add_child(test_btn)

	var battery_btn := _make_menu_item("Allow background (battery)", false)
	battery_btn.pressed.connect(func(): notify_plugin.requestBatteryExemption())
	outer.add_child(battery_btn)

	var refresh_btn := _make_menu_item("Refresh", false)
	refresh_btn.pressed.connect(func():
		overlay.queue_free()
		_open_notify_dialog()
	)
	outer.add_child(refresh_btn)


# -------------------- Theme (အရောင် + Dark mode) --------------------

# theme_id + dark_mode ကနေ COLOR_* အားလုံးကို တွက်တယ်။ UI ကို ပြန်မဆောက်ခင် ခေါ်ရမယ်
func _apply_theme() -> void:
	var accent: Color = _themes[0]["accent"]
	for t in _themes:
		if str(t["id"]) == theme_id:
			accent = t["accent"]
	var h: float = accent.h
	COLOR_GREEN = accent
	COLOR_ON_ACCENT = Color(1, 1, 1)
	COLOR_TOAST_FG = Color(1, 1, 1)
	if dark_mode:
		# မျက်စိမနာအောင် အမည်းစစ်မသုံးဘဲ accent အရောင်ဘက် ယိမ်းတဲ့ အမှောင်ရောင်
		COLOR_BG = Color.from_hsv(h, 0.22, 0.105)
		COLOR_WHITE = Color.from_hsv(h, 0.20, 0.165)
		COLOR_GREEN_LIGHT = Color.from_hsv(h, 0.20, 0.225)
		COLOR_GREEN_DARK = Color.from_hsv(h, 0.10, 0.93)
		COLOR_GREEN_MUTED = Color.from_hsv(h, 0.14, 0.70)
		COLOR_ACCENT_TEXT = Color.from_hsv(h, 0.38, 0.85)
		COLOR_ACCENT_HOVER = accent.lightened(0.12)
		COLOR_CHIP_HOVER = Color.from_hsv(h, 0.22, 0.29)
		COLOR_SHADOW = Color(0, 0, 0, 0.35)
		COLOR_DIM = Color(0, 0, 0, 0.6)
		COLOR_TOAST_BG = Color.from_hsv(h, 0.30, 0.30, 0.96)
	else:
		COLOR_BG = Color.from_hsv(h, 0.05, 0.965)
		COLOR_WHITE = Color(1, 1, 1)
		COLOR_GREEN_LIGHT = Color.from_hsv(h, 0.065, 0.945)
		COLOR_GREEN_DARK = Color.from_hsv(h, 0.62, 0.30)
		COLOR_GREEN_MUTED = Color.from_hsv(h, 0.30, 0.43)
		COLOR_ACCENT_TEXT = accent
		COLOR_ACCENT_HOVER = accent.darkened(0.25)
		COLOR_CHIP_HOVER = Color.from_hsv(h, 0.12, 0.92)
		COLOR_SHADOW = Color(accent.r, accent.g, accent.b, 0.18)
		COLOR_DIM = Color(0.05, 0.10, 0.07, 0.45)
		COLOR_TOAST_BG = Color(COLOR_GREEN_DARK.r, COLOR_GREEN_DARK.g, COLOR_GREEN_DARK.b, 0.94)
	RenderingServer.set_default_clear_color(COLOR_BG)


# UI တစ်ခုလုံးကို အရောင်သစ်နဲ့ ပြန်ဆောက်တယ် (Sync / Timer node တွေကို မထိဘူး)
func _rebuild_ui() -> void:
	if _toast_tween != null and _toast_tween.is_valid():
		_toast_tween.kill()
	for c in get_children():
		if c == sync or c == live_timer or c == clock_timer:
			continue
		remove_child(c)
		c.queue_free()
	_build_ui()
	_build_toast()
	_render_table(false)
	if not _last_live.is_empty():
		_live_signature = ""
		_on_live_ready(_last_live)


# Theme dialog ထဲက ရွေးမှု ပြောင်းတာကို frame အဆုံးမှာ လုပ် (နှိပ်လိုက်တဲ့ ခလုတ်ကိုယ်တိုင်ကို ချက်ချင်းမဖျက်အောင်)
func _theme_changed() -> void:
	_save_state()
	_apply_theme()
	_rebuild_ui()
	_open_theme_dialog()


func _open_theme_dialog() -> void:
	var built := _make_overlay_card(300)
	var overlay: ColorRect = built["overlay"]
	var outer: VBoxContainer = built["outer"]

	_make_title_row(outer, "Theme", func(): overlay.queue_free())

	outer.add_child(_make_menu_heading("Color"))
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	outer.add_child(grid)
	for t in _themes:
		var tid: String = str(t["id"])
		var col: Color = t["accent"]
		var chosen: bool = (tid == theme_id)
		var swatch := Button.new()
		swatch.custom_minimum_size = Vector2(54, 54)
		swatch.tooltip_text = str(t["name"])
		swatch.text = "✓" if chosen else ""
		swatch.add_theme_font_size_override("font_size", 22)
		swatch.add_theme_color_override("font_color", COLOR_ON_ACCENT)
		swatch.add_theme_color_override("font_hover_color", COLOR_ON_ACCENT)
		swatch.add_theme_color_override("font_pressed_color", COLOR_ON_ACCENT)
		for state in ["normal", "hover", "pressed", "focus"]:
			var sb := _pill_style(col, 27)
			if chosen:
				sb.set_border_width_all(3)
				sb.border_color = COLOR_GREEN_DARK
			swatch.add_theme_stylebox_override(state, sb)
		swatch.pressed.connect(func():
			theme_id = tid
			call_deferred("_theme_changed")
		)
		grid.add_child(swatch)

	outer.add_child(_make_menu_heading("Mode"))
	var mode_row := HBoxContainer.new()
	mode_row.add_theme_constant_override("separation", 10)
	outer.add_child(mode_row)
	var light_btn := _make_picker_item_button("Light", not dark_mode)
	light_btn.custom_minimum_size = Vector2(0, 44)
	light_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	light_btn.pressed.connect(func():
		dark_mode = false
		call_deferred("_theme_changed")
	)
	mode_row.add_child(light_btn)
	var dark_btn := _make_picker_item_button("Dark", dark_mode)
	dark_btn.custom_minimum_size = Vector2(0, 44)
	dark_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	dark_btn.pressed.connect(func():
		dark_mode = true
		call_deferred("_theme_changed")
	)
	mode_row.add_child(dark_btn)


# -------------------- Persistent storage (on-device) --------------------

func _save_data() -> void:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		file.close()


func _load_data() -> void:
	data = []
	if FileAccess.file_exists(SAVE_PATH):
		var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if file:
			var text := file.get_as_text()
			file.close()
			var parsed = JSON.parse_string(text)
			if typeof(parsed) == TYPE_ARRAY:
				for item in parsed:
					if typeof(item) == TYPE_DICTIONARY:
						data.append(item)


func _save_state() -> void:
	var file := FileAccess.open(STATE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify({"checked": checked.keys(), "newest_first": newest_first, "theme": theme_id, "dark": dark_mode}))
		file.close()


func _load_state() -> void:
	checked = {}
	if FileAccess.file_exists(STATE_PATH):
		var file := FileAccess.open(STATE_PATH, FileAccess.READ)
		if file:
			var text := file.get_as_text()
			file.close()
			var parsed = JSON.parse_string(text)
			if typeof(parsed) == TYPE_DICTIONARY:
				if parsed.get("checked") is Array:
					for d in parsed["checked"]:
						checked[str(d)] = true
				if parsed.has("newest_first"):
					newest_first = bool(parsed["newest_first"])
				if parsed.has("theme"):
					theme_id = str(parsed["theme"])
				if parsed.has("dark"):
					dark_mode = bool(parsed["dark"])

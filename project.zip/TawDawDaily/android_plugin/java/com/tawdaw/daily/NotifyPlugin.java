package com.tawdaw.daily;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;


import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.GodotPlugin;
import org.godotengine.godot.plugin.UsedByGodot;

/**
 * GDScript ကနေ ခေါ်တဲ့ တံခါး။
 *   var p = Engine.get_singleton("TawDawNotify")
 *   p.setEnabled(true)   # Notification ဖွင့်/ပိတ် (permission တောင်းမယ်၊ alarm ချိန်မယ်)
 *   p.isEnabled()        # ဖွင့်ထားလား
 *   p.canExactAlarm()    # အချိန်တိကျ alarm ခွင့်ရှိလား (Android 12+)
 * Method နာမည်တွေကို GDScript မှာ ဒီအတိုင်း (camelCase) ခေါ်ရမယ်။
 */
public class NotifyPlugin extends GodotPlugin {
	private static final int REQ_NOTIFY = 7001;

	public NotifyPlugin(Godot godot) {
		super(godot);
	}

	@Override
	public String getPluginName() {
		return "TawDawNotify";
	}

	@UsedByGodot
	public void setEnabled(boolean on) {
		Activity a = getActivity();
		if (a == null) {
			return;
		}
		Scheduler.setEnabled(a, on);
		if (on) {
			if (Build.VERSION.SDK_INT >= 33
					&& a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
							!= PackageManager.PERMISSION_GRANTED) {
				a.requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, REQ_NOTIFY);
			}
			Scheduler.scheduleNext(a, 0);
		} else {
			Scheduler.cancel(a);
		}
	}

	@UsedByGodot
	public boolean isEnabled() {
		Activity a = getActivity();
		return a != null && Scheduler.isEnabled(a);
	}

	@UsedByGodot
	public boolean canExactAlarm() {
		Activity a = getActivity();
		return a != null && Scheduler.canExact(a);
	}
}

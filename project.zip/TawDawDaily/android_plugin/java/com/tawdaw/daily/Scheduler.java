package com.tawdaw.daily;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;
import java.util.TimeZone;

/** နောက်ထွက်မယ့် အချိန်အတွက် alarm တစ်ခုချင်း ချိန်တယ်။ ထွက်ပြီးတိုင်း နောက်တစ်ခု ထပ်ချိန်တယ်။ */
final class Scheduler {
	static final String PREFS = "tawdaw_notify";
	static final String KEY_ENABLED = "enabled";
	static final String ACTION_TICK = "com.tawdaw.daily.TICK";
	static final String EXTRA_SLOT = "slot";
	static final String EXTRA_ATTEMPT = "attempt";

	// Thai အချိန် 11:00, 12:01, 15:00, 16:30 (မိနစ်နဲ့)
	static final int[] SLOT_MINUTES = { 660, 721, 900, 990 };
	static final String[] SLOT_LABELS = { "11:00 AM", "12:00 PM", "3:00 PM", "4:30 PM" };
	static final TimeZone THAI = TimeZone.getTimeZone("Asia/Bangkok");

	// ထွက်ချိန်ကနေ ဘယ်နှစ်စက္ကန့်နောက်မှ ပထမဆုံး မေးမလဲ၊ မပေါ်သေးရင် ဘယ်နှစ်စက္ကန့်ခြားပြီး ထပ်မေးမလဲ
	static final int FIRST_DELAY_SEC = 8;
	static final int RETRY_DELAY_SEC = 40;
	static final int MAX_ATTEMPTS = 9;

	private Scheduler() {}

	static boolean isEnabled(Context c) {
		return prefs(c).getBoolean(KEY_ENABLED, false);
	}

	static void setEnabled(Context c, boolean on) {
		prefs(c).edit().putBoolean(KEY_ENABLED, on).apply();
	}

	static SharedPreferences prefs(Context c) {
		return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
	}

	static boolean canExact(Context c) {
		if (Build.VERSION.SDK_INT < 31) {
			return true;
		}
		AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
		return am != null && am.canScheduleExactAlarms();
	}

	/** နောက်ထွက်မယ့် slot (Mon-Fri) ကို ရှာပြီး alarm ချိန်တယ်။ */
	static void scheduleNext(Context c, int ignored) {
		if (!isEnabled(c)) {
			return;
		}
		long now = System.currentTimeMillis();
		for (int day = 0; day < 8; day++) {
			for (int i = 0; i < SLOT_MINUTES.length; i++) {
				Calendar d = Calendar.getInstance(THAI);
				d.setTimeInMillis(now);
				d.add(Calendar.DAY_OF_MONTH, day);
				int dow = d.get(Calendar.DAY_OF_WEEK);
				if (dow == Calendar.SATURDAY || dow == Calendar.SUNDAY) {
					continue;
				}
				d.set(Calendar.HOUR_OF_DAY, SLOT_MINUTES[i] / 60);
				d.set(Calendar.MINUTE, SLOT_MINUTES[i] % 60);
				d.set(Calendar.SECOND, FIRST_DELAY_SEC);
				d.set(Calendar.MILLISECOND, 0);
				if (d.getTimeInMillis() > now + 1000) {
					setAlarm(c, d.getTimeInMillis(), i, 0);
					return;
				}
			}
		}
	}

	/** ရလဒ်မပေါ်သေးရင် ခဏနေ ပြန်မေးဖို့ */
	static void scheduleRetry(Context c, int slot, int attempt) {
		setAlarm(c, System.currentTimeMillis() + RETRY_DELAY_SEC * 1000L, slot, attempt);
	}

	static void cancel(Context c) {
		AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
		if (am != null) {
			am.cancel(pending(c, 0, 0));
		}
	}

	private static void setAlarm(Context c, long triggerAtMs, int slot, int attempt) {
		AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
		if (am == null) {
			return;
		}
		PendingIntent pi = pending(c, slot, attempt);
		try {
			if (canExact(c)) {
				am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
			} else {
				// Exact alarm ခွင့်မရှိရင် ဖုန်းက နည်းနည်းနောက်ကျစေနိုင်တဲ့ alarm နဲ့ အစားထိုး
				am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
			}
		} catch (SecurityException e) {
			am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
		}
	}

	// requestCode တူရင် အရင် alarm ကို အစားထိုးတာမို့ တစ်ချိန်မှာ alarm တစ်ခုပဲ ရှိမယ်
	private static PendingIntent pending(Context c, int slot, int attempt) {
		Intent i = new Intent(c, SlotReceiver.class);
		i.setAction(ACTION_TICK);
		i.putExtra(EXTRA_SLOT, slot);
		i.putExtra(EXTRA_ATTEMPT, attempt);
		int flags = PendingIntent.FLAG_UPDATE_CURRENT;
		if (Build.VERSION.SDK_INT >= 23) {
			flags |= PendingIntent.FLAG_IMMUTABLE;
		}
		return PendingIntent.getBroadcast(c, 4242, i, flags);
	}
}

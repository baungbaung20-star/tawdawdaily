package com.tawdaw.daily;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Alarm ထွက်တဲ့အခါ /live ကို မေးပြီး ဒီ slot ရဲ့ ရလဒ်ပါမပါ စစ်တယ်။
 * ပါရင် Notification ပြတယ်၊ မပါသေးရင် ခဏနေ ပြန်မေးတယ် (Scheduler.MAX_ATTEMPTS အထိ)။
 * goAsync() က ~10 စက္ကန့်ပဲ ပေးတာမို့ network timeout ကို တိုတိုထားတယ်။
 */
public class SlotReceiver extends BroadcastReceiver {
	private static final String LIVE_URL = "https://api.thaistock2d.com/live";
	private static final String CHANNEL_ID = "results";
	private static final int SLOT_TOLERANCE = 45;

	private String detail = "";

	private static final class Result {
		String twod = "";
		String set = "";
		String value = "";
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		if (intent == null || !Scheduler.ACTION_TICK.equals(intent.getAction())) {
			return;
		}
		final Context app = context.getApplicationContext();
		final int slot = intent.getIntExtra(Scheduler.EXTRA_SLOT, 0);
		final int attempt = intent.getIntExtra(Scheduler.EXTRA_ATTEMPT, 0);
		Scheduler.log(app, "fired " + Scheduler.SLOT_LABELS[slot] + " try " + attempt);
		final PendingResult pr = goAsync();
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					handle(app, slot, attempt);
				} catch (Throwable t) {
					Scheduler.log(app, "error: " + t);
					retryOrNext(app, slot, attempt);
				} finally {
					pr.finish();
				}
			}
		}).start();
	}

	private void handle(Context app, int slot, int attempt) throws Exception {
		if (!Scheduler.isEnabled(app)) {
			return;
		}
		String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US) {
			{
				setTimeZone(Scheduler.THAI);
			}
		}.format(new Date());

		Result r = fetch(slot, today);
		if (r != null) {
			String key = "n_" + today + "_" + slot;
			if (!Scheduler.prefs(app).getBoolean(key, false)) {
				showNotification(app, slot, r);
				Scheduler.prefs(app).edit().putBoolean(key, true).apply();
				Scheduler.log(app, "notified " + Scheduler.SLOT_LABELS[slot] + " = " + r.twod);
			}
			Scheduler.scheduleNext(app, 0);
		} else {
			Scheduler.log(app, "no result yet (" + detail + ")");
			retryOrNext(app, slot, attempt);
		}
	}

	private void retryOrNext(Context app, int slot, int attempt) {
		if (attempt + 1 < Scheduler.MAX_ATTEMPTS) {
			Scheduler.scheduleRetry(app, slot, attempt + 1);
		} else {
			Scheduler.scheduleNext(app, 0); // ရက်ရှည်ပိတ်ရက်စတဲ့ အခြေအနေ - လက်လျှော့ပြီး နောက်တစ်ခုကို
		}
	}

	/** ဒီနေ့ရဲ့ ဒီ slot ရလဒ်ပါရင် Result၊ မပါသေးရင် null */
	private Result fetch(int slot, String today) throws Exception {
		HttpURLConnection conn = (HttpURLConnection) new URL(LIVE_URL).openConnection();
		conn.setConnectTimeout(4000);
		conn.setReadTimeout(4000);
		conn.setRequestProperty("Accept", "application/json");
		String body;
		try {
			int code = conn.getResponseCode();
			if (code != 200) {
				detail = "http " + code;
				return null;
			}
			InputStream in = conn.getInputStream();
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buf = new byte[4096];
			int n;
			while ((n = in.read(buf)) > 0) {
				out.write(buf, 0, n);
			}
			body = out.toString("UTF-8");
		} finally {
			conn.disconnect();
		}

		JSONArray rows = new JSONObject(body).optJSONArray("result");
		if (rows == null) {
			detail = "no result array";
			return null;
		}
		String latest = "";
		if (rows.length() > 0 && rows.optJSONObject(0) != null) {
			JSONObject r0 = rows.optJSONObject(0);
			latest = " first=" + r0.optString("stock_date", "?") + " " + r0.optString("open_time", "?");
		}
		detail = "rows=" + rows.length() + " today=" + today + latest;
		Result best = null;
		long bestId = Long.MIN_VALUE;
		for (int i = 0; i < rows.length(); i++) {
			JSONObject row = rows.optJSONObject(i);
			if (row == null) {
				continue;
			}
			if (!today.equals(normDate(row.optString("stock_date", row.optString("date", ""))))) {
				continue;
			}
			if (slotIndex(row.optString("open_time", row.optString("time", ""))) != slot) {
				continue;
			}
			String twod = row.optString("twod", "").trim();
			if (!twod.matches("\\d\\d")) {
				continue;
			}
			long id = row.optLong("history_id", 0);
			if (best == null || id >= bestId) {
				best = new Result();
				best.twod = twod;
				best.set = row.optString("set", "").replace(",", "").trim();
				best.value = row.optString("value", "").replace(",", "").trim();
				bestId = id;
			}
		}
		return best;
	}

	// "2026-11-10" ဒါမှမဟုတ် "10-11-2026" -> "2026-11-10"၊ မကိုက်ရင် ""
	private static String normDate(String s) {
		s = s.trim();
		if (s.matches("\\d{4}-\\d{2}-\\d{2}.*")) {
			return s.substring(0, 10);
		}
		if (s.matches("\\d{2}-\\d{2}-\\d{4}.*")) {
			return s.substring(6, 10) + "-" + s.substring(3, 5) + "-" + s.substring(0, 2);
		}
		return "";
	}

	// "12:01:00" -> 1၊ မကိုက်ရင် -1
	private static int slotIndex(String t) {
		String[] p = t.trim().split(":");
		if (p.length < 2) {
			return -1;
		}
		int mins;
		try {
			mins = Integer.parseInt(p[0].trim()) * 60 + Integer.parseInt(p[1].trim());
		} catch (NumberFormatException e) {
			return -1;
		}
		int best = -1;
		int bestDiff = SLOT_TOLERANCE + 1;
		for (int i = 0; i < Scheduler.SLOT_MINUTES.length; i++) {
			int diff = Math.abs(mins - Scheduler.SLOT_MINUTES[i]);
			if (diff < bestDiff) {
				bestDiff = diff;
				best = i;
			}
		}
		return best;
	}

	private void showNotification(Context ctx, int slot, Result r) {
		String title = Scheduler.SLOT_LABELS[slot] + "   2D  " + r.twod;
		StringBuilder text = new StringBuilder();
		if (!r.set.isEmpty()) {
			text.append("SET ").append(r.set);
		}
		if (!r.value.isEmpty()) {
			if (text.length() > 0) {
				text.append("  ·  ");
			}
			text.append("Value ").append(r.value);
		}
		show(ctx, 1000 + slot, title, text.toString());
	}

	/** Notification တစ်ခု ပြတယ် (စမ်းသပ်တာနဲ့ ရလဒ်ပြတာ နှစ်ခုလုံး သုံး) */
	static void show(Context ctx, int id, String title, String body) {
		NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
		if (nm == null) {
			return;
		}
		if (Build.VERSION.SDK_INT >= 26) {
			NotificationChannel ch = new NotificationChannel(
					CHANNEL_ID, "2D results", NotificationManager.IMPORTANCE_HIGH);
			nm.createNotificationChannel(ch);
		}

		Intent launch = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
		PendingIntent tap = null;
		if (launch != null) {
			int flags = PendingIntent.FLAG_UPDATE_CURRENT;
			if (Build.VERSION.SDK_INT >= 23) {
				flags |= PendingIntent.FLAG_IMMUTABLE;
			}
			tap = PendingIntent.getActivity(ctx, 0, launch, flags);
		}

		Notification.Builder b = Build.VERSION.SDK_INT >= 26
				? new Notification.Builder(ctx, CHANNEL_ID)
				: new Notification.Builder(ctx);
		b.setSmallIcon(android.R.drawable.ic_dialog_info)
				.setContentTitle(title)
				.setContentText(body)
				.setAutoCancel(true)
				.setWhen(System.currentTimeMillis());
		if (tap != null) {
			b.setContentIntent(tap);
		}
		try {
			nm.notify(id, b.build());
		} catch (SecurityException ignored) {
			// POST_NOTIFICATIONS ခွင့်မပြုထားရင် ဘာမှမလုပ်
		}
	}
}

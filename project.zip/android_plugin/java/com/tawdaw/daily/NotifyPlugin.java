package com.tawdaw.daily;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.GodotPlugin;
import org.godotengine.godot.plugin.UsedByGodot;

/**
 * GDScript ကနေ ခေါ်တဲ့ တံခါး။
 *   var p = Engine.get_singleton("TawDawNotify")
 *   p.setEnabled(true)   # Notification ဖွင့်/ပိတ် (permission တောင်းမယ်၊ alarm ချိန်မယ်)
 *   p.isEnabled()        # ဖွင့်ထားလား
 *   p.canExactAlarm()    # အချိန်တိကျ alarm ခွင့်ရှိလား (Android 12+)
 * Method နာမည်တွေကို GDScript မှာ ဒီအတိုင်း (camelCase) ခေါ်ရမယ်။
 */
public class NotifyPlugin extends GodotPlugin {
	private static final int REQ_NOTIFY = 7001;

	public NotifyPlugin(Godot godot) {
		super(godot);
	}

	@Override
	public String getPluginName() {
		return "TawDawNotify";
	}

	@UsedByGodot
	public void setEnabled(boolean on) {
		Activity a = getActivity();
		if (a == null) {
			return;
		}
		Scheduler.setEnabled(a, on);
		if (on) {
			if (Build.VERSION.SDK_INT >= 33
					&& a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
							!= PackageManager.PERMISSION_GRANTED) {
				a.requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, REQ_NOTIFY);
			}
			Scheduler.scheduleNext(a, 0);
		} else {
			Scheduler.cancel(a);
		}
	}

	@UsedByGodot
	public boolean isEnabled() {
		Activity a = getActivity();
		return a != null && Scheduler.isEnabled(a);
	}

	@UsedByGodot
	public boolean canExactAlarm() {
		Activity a = getActivity();
		return a != null && Scheduler.canExact(a);
	}

	/** ခွင့်ပြုချက်၊ alarm အခြေအနေ၊ နောက်ဆုံး ဘာဖြစ်ခဲ့လဲ log ကို စာသားအဖြစ် ပြန်ပေး */
	@UsedByGodot
	public String getStatus() {
		Activity a = getActivity();
		if (a == null) {
			return "no activity";
		}
		StringBuilder sb = new StringBuilder();
		sb.append("Enabled: ").append(Scheduler.isEnabled(a) ? "yes" : "NO").append('\n');
		boolean permOk = Build.VERSION.SDK_INT < 33
				|| a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
		NotificationManager nm = (NotificationManager) a.getSystemService(Context.NOTIFICATION_SERVICE);
		boolean shown = nm == null || nm.areNotificationsEnabled();
		sb.append("Notification permission: ").append(permOk && shown ? "granted" : "DENIED").append('\n');
		sb.append("Exact alarm: ").append(Scheduler.canExact(a) ? "yes" : "NO").append('\n');
		PowerManager pm = (PowerManager) a.getSystemService(Context.POWER_SERVICE);
		boolean ign = pm != null && Build.VERSION.SDK_INT >= 23 && pm.isIgnoringBatteryOptimizations(a.getPackageName());
		sb.append("Battery unrestricted: ").append(ign ? "yes" : "NO").append('\n');
		long next = Scheduler.prefs(a).getLong("next_ms", 0);
		if (next > 0) {
			sb.append("Next alarm: ").append(new SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(new Date(next))).append('\n');
		}
		String log = Scheduler.getLog(a);
		sb.append("\nLog (device time):\n").append(log.isEmpty() ? "(empty)" : log);
		return sb.toString();
	}

	@UsedByGodot
	public void testNotify() {
		Activity a = getActivity();
		if (a == null) {
			return;
		}
		if (Build.VERSION.SDK_INT >= 33
				&& a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
			a.requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, REQ_NOTIFY);
		}
		SlotReceiver.show(a.getApplicationContext(), 999, "Test   2D  47", "SET 1234.56  \u00b7  Value 78901.23");
	}

	/** Battery optimization ကနေ ဖယ်ပေးဖို့ system dialog ကို ဖွင့် */
	@UsedByGodot
	public void requestBatteryExemption() {
		Activity a = getActivity();
		if (a == null || Build.VERSION.SDK_INT < 23) {
			return;
		}
		try {
			Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
					Uri.parse("package:" + a.getPackageName()));
			a.startActivity(i);
		} catch (Exception e) {
			try {
				a.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
			} catch (Exception ignored) {
			}
		}
	}
}

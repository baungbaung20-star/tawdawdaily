package com.tawdaw.daily;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** ဖုန်းပြန်ဖွင့်ပြီး (သို့) App update လုပ်ပြီးရင် alarm တွေ ပျောက်သွားလို့ ပြန်ချိန်ပေးတယ်။ */
public class BootReceiver extends BroadcastReceiver {
	@Override
	public void onReceive(Context context, Intent intent) {
		Scheduler.scheduleNext(context.getApplicationContext(), 0);
	}
}

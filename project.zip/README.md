# Taw Daw Daily (Godot 4.7.2)

## အကျဉ်းချုပ်
ဤ Project သည် **Taw Daw Calendar** (AttendanceApp) ၏ ဖွဲ့စည်းပုံ၊ UI၊ Menu များကို အတိုင်းလိုက်ပြီး၊ နေ့စဉ် **2D ရလဒ် ၄ ကြိမ်** ကို API မှ အလိုအလျောက်ယူကာ ပြသပေးသော app ဖြစ်ပါသည်။

- Screen ထိပ်ဆုံးမှာ **"Taw Daw Daily"** ခေါင်းစီး အလယ်တွင်ရှိပြီး **⚙ Settings ခလုတ်ကို App ၏ ညာဘက်အပေါ်ထောင့်အစွန်** (ခေါင်းစီးထက်မြင့်သောနေရာ၊ အသေးလေး) တွင် ထားပါသည်။
- ခေါင်းစီးအောက်တွင် **ဖုန်း၏ လက်ရှိအချိန် (စက္ကန့်ပါ)** ကို ပြပါသည်။ ဥပမာ `Mon, 2026-11-09   10:19:05`
- ၎င်းအောက်တွင် **LIVE card** ရှိပါသည်။ `/live` ၏ `live` အပိုင်း (အခု ပြောင်းနေသော 2D နံပါတ်၊ SET၊ Value၊ အချိန်) ကို ပြပါသည်။
  - Live မလာသေးလျှင် (API က `--` ပေးလျှင်၊ ဈေးပိတ်ထားလျှင်၊ ရက်စွဲမတူလျှင်) **ပြုံးနေသော မျက်နှာ** ပြပါသည်။ (Font မလိုဘဲ code ဖြင့် ဆွဲထားသဖြင့် Emoji font မရှိသော ဖုန်းတွင်လည်း ပေါ်ပါသည်။)
  - ထိုင်းအချိန် တနင်္လာ–သောကြာ ၀၉:၃၀–၁၆:၅၀ အတွင်း **၉ စက္ကန့်တစ်ကြိမ်** အလိုအလျောက် ပြန်မေးပါသည်။ (Source က ၇–၈ စက္ကန့်လောက်တစ်ခါ ပြောင်းပါသည်။ ဆက်တိုက် ၃ ကြိမ် မအောင်မြင်လျှင် ၁ မိနစ် ရပ်စောင့်ပါသည်။) (`Main.gd` ထိပ်က `LIVE_REFRESH_SECONDS`) ဈေးပိတ်ချိန်တွင် မမေးပါ။
  - Live ကို မေးရင်းနှင့် ထွက်ပြီးသော ရလဒ် ၄ ကြိမ်ကိုလည်း ဇယားထဲ ထည့်ပေးပါသည်။
- ဇယား Header တွင် အချိန် ၄ ခု − **11:00 AM | 12:00 PM | 3:00 PM | 4:30 PM**။
- ရက်စွဲတစ်ခုချင်းစီအတွက် Entry Block တစ်ခုစီ။ ထိပ်မှာ **"Weekday, YYYY-MM-DD"** label ရှိပြီး၊ Edit mode ဖွင့်ထားလျှင် ✏ ခလုတ် ပေါ်လာပါသည်။
- အကွက်တစ်ခုစီတွင်:
  - **2D နံပါတ်ကို ကြီးကြီး (font 30, bold)** ပြပါသည်။
  - အောက်တွင် **SET** နှင့် **Value** ကို သေးသေး ပြပါသည်။ (ဥပမာ `1482.53` / `34,559.20`)
  - ရလဒ် မထွက်သေးသော အကွက်ကို `--` ဟု ပြပါသည်။
  - **2D က SET/Value နှင့် မကိုက်လျှင်** သေးသေးစာ နှစ်ကြောင်း လိမ္မော်ရောင် ပြောင်းပါသည်။ (ရှင်းလင်းချက် စာတန်း မပြတော့ပါ) (2D = SET ရဲ့ ဒသမ ဒုတိယလုံး + Value ရဲ့ ကိန်းပြည့်အပိုင်း နောက်ဆုံးလုံး)
- ဇယားအပေါ်ညာဘက် (လ/နှစ် စာတန်းနှင့် တစ်တန်းထဲ) တွင် **အစီအစဉ်ပြောင်းခလုတ်** ရှိပါသည်။ `Newest on top` (ရက်အသစ်ဆုံး အပေါ်ဆုံး) ↔ `Newest at bottom` (ရက်အသစ်ဆုံး အောက်ဆုံး၊ ဇယားကို အောက်ဆုံးကနေ စကြည့်ပေးမည်)။ ရွေးထားသည်ကို မှတ်ထားပါသည်။
- ဇယားသည် **လ+နှစ်တစ်ခုစီ** အလိုက် ပြပါသည်။ ရက်အသစ်ဆုံး အပေါ်ဆုံးမှာ ပြပါသည် (အထက်ပါ ခလုတ်ဖြင့် ပြောင်းနိုင်)။
- ✏ ခလုတ် (Edit mode) နှင့် ⚙ ထဲက **Add entry (manual)** က Dialog တစ်ခုတည်း သုံးပါသည်။ ရက်စွဲ (`YYYY-MM-DD`) နှင့် အချိန် ၄ ခုစီအတွက် **2D (ဂဏန်း ၂ လုံး) / SET / Value** Input ၃ ခုစီ ပါပါသည်။
  - Main screen ကနေ "+ Add New" ခလုတ်ကို ဖယ်ထားပါသည်။ ကိုယ်တိုင်ထည့်လိုလျှင် ⚙ Settings ထဲက **Add entry (manual)** ကို သုံးပါ။
  - ရက်စွဲ ရှိပြီးသားကို ထည့်လျှင် ထပ်မနေဘဲ ထို entry ကိုပဲ Update လုပ်ပါသည်။
- ⚙ **Settings (Gear)** Menu:
  - **Today** − လက်ရှိလ/နှစ်သို့ ပြန်သွားမည်
  - **Edit entries / Done editing** − ✏ ခလုတ်များ ဖော်/ဖျောက်မည်
  - **Sort (Month / Year)** − လနှင့်နှစ်ကို ရွေးကြည့်မည်
  - **Add entry (manual)** − ရက်တစ်ရက်ကို ကိုယ်တိုင်ထည့်မည်
  - **Sync now** − API မှ ပြန်ယူမည်
  - **Import Backup (.json)** / **Export Backup (.json)**
  - **Exit App**
- **Portrait** နှင့် **Landscape** နှစ်မျိုးလုံး Support လုပ်ပါသည်။ Menu/Dialog များ ရှည်လျှင် Scroll လုပ်လို့ရပါသည်။

## API Sync (အလိုအလျောက် ယူခြင်း)
App ဖွင့်တိုင်း `scripts/ApiSync.gd` က `https://api.thaistock2d.com` မှ ယူပါသည်။ Sync အခြေအနေကို Screen အောက်ခြေတွင် **Toast** (ခဏပေါ်ပြီး ပျောက်သွားသော စာတန်း) ဖြင့် ပြပါသည်။ (Syncing... → Up to date / Updated N day(s))

1. `/live` − ယနေ့ (သို့) နောက်ဆုံးအလုပ်လုပ်ခဲ့သောနေ့၏ ရလဒ် *(Response ပုံစံ တကယ်စမ်းပြီး အတည်ပြုထား)*
2. `/2d_result` − နောက်ဆုံး ၁၀ ရက် *(docs အရ ရေးထား၊ မစမ်းရသေး)*
3. `/2d_result?date=DD-MM-YYYY` − ကျန်နေသော ရက်များ (ရက် ၃၁ ရက်အထိ၊ စနေ/တနင်္ဂနွေ ကျော်) *(docs အရ ရေးထား၊ မစမ်းရသေး)*

- App မဖွင့်ထားသော ရက်များကို နောက်တစ်ကြိမ် ဖွင့်ချိန်တွင် ပြန်ဖြည့်ပေးပါသည် (Gap-filling)။
- ပြည့်စုံပြီးသား (၄ ကြိမ်လုံးပါ) ရက်၊ ပိတ်ရက်ဟု စစ်ပြီးသော အတိတ်ရက်များကို ထပ်မမေးတော့ပါ။
- **ကိုယ်တိုင်ပြင်ထားသော အကွက်ကို API က ပြန်မထိပါ။** (entry ထဲက `manual` list တွင် မှတ်ထားသည်။) အကွက်တစ်ခုလုံးကို ဖျက်ထုတ် (2D/SET/Value အလွတ်) လိုက်လျှင် server ကပြန်ဖြည့်ခွင့် ရပါသည်။
- Response ပုံစံ မသိသည့်အခါ data မသိမ်းဘဲ Toast တွင် `unexpected response format` ဟု ပိုကြာကြာ ပြပါမည်။ (Godot Output panel တွင်လည်း `2D:` warning ထွက်ပါမည်။)
- ရလဒ်များကို **ထိုင်းရက်စွဲ** ဖြင့် သိမ်းပါသည်။

## ဖွင့်နည်း
1. [Godot Engine 4.7.2](https://godotengine.org/download) ကို Download လုပ်ပါ။
2. Godot Project Manager ဖွင့်ပြီး **Import** → ဒီ folder ထဲက `project.godot` ဖိုင်ကို ရွေးပါ။
3. **Run Project** (F5) နှိပ်ပြီး စမ်းသပ်နိုင်ပါသည်။

## Android/iOS App အဖြစ် Export လုပ်နည်း
1. **Editor → Manage Export Templates** မှ Export Templates များကို Install လုပ်ပါ။
2. **Project → Export** တွင် Android preset ထည့်ပါ။ **Package/Unique Name** ကို `com.example.$genname` အစား ကိုယ်ပိုင် (ဥပမာ `com.yourname.tawdawdaily`) ပြောင်းပါ။
3. ⚠ **Export preset ထဲက Permissions စာရင်းတွင် `Internet` ကို အမှန်ခြစ် (ON) လုပ်ပါ။** မလုပ်လျှင် ဖုန်းပေါ်တွင် API ခေါ်လို့မရပါ (Toast တွင် `Sync failed` ဟု ပြပါမည်)။
4. **Export Project** နှိပ်၍ `.apk` ထုတ်ပါ။

## Project Structure
```
TawDawDaily/
├── project.godot        # Godot project configuration (App name: "Taw Daw Daily")
├── icon.svg             # App icon (green theme)
├── assets/
│   └── gear.svg         # Settings (gear) button icon
├── scenes/
│   └── Main.tscn        # Root scene (single Control node)
├── android_plugin/      # Notification Java code + export plugin
├── ci/                  # GitHub Actions build script
└── scripts/
    ├── Main.gd          # UI + table + dialogs (Add/Edit, Sort) + save/load + backup
    ├── ApiSync.gd       # API ကနေ ရလဒ်ယူခြင်း (UI မပါ၊ signal နဲ့ Main.gd ကို အကြောင်းကြား)
    └── DayCalc.gd       # Excel "For Taw Daw" Sheet ရဲ့ ဖော်မြူလာ (UI မပါ)
```

## Data ဆိုင်ရာ မှတ်ချက်
- `user://daily_data.json` တွင် JSON Array of Object အဖြစ် သိမ်းပါသည်။ တစ်ရက်စာ Entry:
```json
{
  "date": "2026-11-06",
  "slot1": "39", "set1": "1482.53", "val1": "34559.20",
  "slot2": "51", "set2": "1473.85", "val2": "43111.03",
  "slot3": "08", "set3": "1467.9",  "val3": "63958.29",
  "slot4": "05", "set4": "1465.7",  "val4": "79435.65",
  "manual": []
}
```
  - `slotN` = 2D နံပါတ် (Taw Daw Calendar နှင့် key တူသည်)၊ `setN` = SET၊ `valN` = Value။
  - `manual` = ကိုယ်တိုင်ပြင်ထားသော အကွက်များ (ဥပမာ `["slot2"]`)။
- `user://sync_state.json` တွင် စစ်ပြီးသော အတိတ်ရက်များကို မှတ်ထားပါသည်။
- Plain Text ဖြစ်ပြီး Encrypt မလုပ်ထားပါ။

## Backup ဖိုင် ဆိုင်ရာ မှတ်ချက်
- Backup ဖိုင်သည် `daily_data.json` နှင့် ပုံစံတူ JSON Array (`taw_daw_daily_backup_YYYY-MM-DD.json`)။
- Import လုပ်ရာတွင် ရက်စွဲတူလျှင် Backup ထဲတွင် **ပါသော field များသာ** ပြောင်းပြီး မပါသော field ကို မဖျက်ပါ။ ထို့ကြောင့် **Taw Daw Calendar ၏ Backup (slot1–slot4 သာပါ) ကိုလည်း Import လုပ်လို့ရပါသည်။**
- ရက်စွဲ `YYYY-MM-DD` မမှန်သော Entry များကို ကျော်ပြီး Message ဖြင့် ပြပါမည်။

## Notification (Android၊ App ပိတ်ထားလည်း အလုပ်လုပ်)
ရလဒ် ၄ ကြိမ် (11:00, 12:01, 15:00, 16:30 Thai အချိန်၊ တနင်္ဂနွေ/စနေ မပါ) ထွက်တိုင်း `/live` ကို အလိုအလျောက်မေးပြီး ထွက်သွားတဲ့ နံပါတ်ကို Notification ပြပါတယ်။ ရလဒ်မပေါ်သေးရင် ၄၀ စက္ကန့်ခြားပြီး ၉ ကြိမ်အထိ ပြန်မေးပါတယ်။

ဒါက Android native (Java) ဖြစ်လို့ **Gradle build** နဲ့မှ ပါပါတယ်။ ဖုန်းထဲက Godot editor က Gradle build မလုပ်နိုင်လို့ **GitHub Actions** နဲ့ APK build လုပ်ပါတယ်။
- `android_plugin/` = Java code + Godot export plugin၊ `ci/` = build script, export preset, debug keystore။
- `.github/workflows/build-apk.yml` = Godot 4.7.2 ကို download ပြီး APK ထုတ်ပေးတဲ့ workflow။
- ဒီ folder တွေက APK ထဲ မပါပါဘူး (export filter နဲ့ ဖယ်ထားတယ်)။

### Build လုပ်နည်း
1. GitHub repo အသစ်တစ်ခုဆောက်ပါ။
2. `project.zip` (ထဲမှာ `TawDawDaily/` folder) နဲ့ `.github/workflows/build-apk.yml` ကို repo ထဲ တင်ပါ။
3. `project.zip` ကို push လုပ်တိုင်း (ဒါမှမဟုတ် Actions → Run workflow) APK ထွက်ပါတယ်၊ **Releases** မှာ download လုပ်ပါ။

### သုံးနည်း
- Install လုပ်ပြီး ပထမဆုံး ဖွင့်တာနဲ့ **Notification က ON ဖြစ်နေပြီးသား** ပါ၊ ခွင့်ပြုချက် (Android 13+) တောင်းရင် ခွင့်ပြုပါ။ ပိတ်ချင်ရင် ⚙ → **Result notifications: ON** ကို နှိပ်ပါ။
- Android 12+ မှာ **Alarms & reminders** ခွင့်မပေးရင် Notification က မိနစ်အနည်းငယ် နောက်ကျနိုင်ပါတယ်။
- ဖုန်း battery saver ပိတ်တတ်ရင် App ကို **Battery → Unrestricted** ပေးပါ။
- Notification ပြပြီးသား အကြိမ်ကို ထပ်မပြပါဘူး။ App ဖွင့်တဲ့အခါ ပုံမှန် Sync က table ကို ဖြည့်ပေးပါတယ်။

⚠ Plugin မပါတဲ့ ပုံမှန် build (ဥပမာ ဖုန်း editor ကနေ export) မှာ `Result notifications` menu မပေါ်ပါ၊ တခြားအားလုံး ပုံမှန်အတိုင်းပါ။
⚠ iOS မှာ App ပိတ်ထားရင် အချိန်အတိ background fetch မလုပ်နိုင်ပါ။

## Theme (အရောင် / Dark mode)
⚙ → **Theme (Color / Dark mode)** မှာ accent အရောင် ၇ မျိုး (အစိမ်း၊ နီ၊ ဝါ၊ လိမ္မော်၊ ပြာ၊ ခရမ်း၊ ပန်းရောင်) နဲ့ **Light / Dark** ကို ရွေးလို့ရပါတယ်။ Dark mode က မျက်စိမနာအောင် အမည်းစစ်မဟုတ်ဘဲ ရွေးထားတဲ့ အရောင်ဘက်ယိမ်းတဲ့ အမှောင်ရောင်ကို သုံးပါတယ်။ ရွေးထားတာကို မှတ်ထားပါတယ် (`sync_state.json`)။

## Notification စစ်ဆေးရန်
⚙ → **Notification status / test** မှာ ခွင့်ပြုချက်၊ Exact alarm၊ Battery၊ နောက်ထပ် alarm အချိန်၊ နောက်ဆုံး ဖြစ်ခဲ့တာ log ကို ကြည့်လို့ရပါတယ်။ **Send test notification** နဲ့ ချက်ချင်း စမ်းနိုင်ပြီး **Allow background (battery)** က Battery restriction ကို ဖယ်ဖို့ system dialog ဖွင့်ပါတယ်။

## Formula table (Excel "For Taw Daw" Sheet)
⚙ → **Formula table** မှာ ရက်တစ်ရက်စီအတွက် Excel ဖိုင်ရဲ့ **"For Taw Daw"** Sheet ကို App ထဲမှာ ပြန်တွက်ပြီး **Prediction (A17)** ကို ပြပါတယ်။

ရက်စွဲကို အပြင်က Table လိုပဲ row တစ်ခုစီရဲ့ ဘယ်အပေါ်ထောင့်မှာ ပြပါတယ်။ **Newest on top / Newest at bottom** ခလုတ်ကို နှိပ်ရင် အပြင်က Table နဲ့ အတူ အစီအစဉ်ပြောင်းပါတယ်။
- ဇယားမှာ `Date | A | B / C` ပါပြီး အတန်းတိုင်းရဲ့ အောက်မှာ 11:00 / 12:00 / 3:00 / 4:30 နံပါတ် ၄ ခုကို သေးသေးပြပါတယ် (ဖော်မြူလာသုံးတဲ့ 12:00 နဲ့ 4:30 ကို အရောင်ထင်ရှားပြ)။ Prediction က ၂ လုံးတွဲ (မနက်ဖြန်အတွက် A) ဒါမှမဟုတ် `A = 2, B = 27.49 (RL), C = 27.50 (BK)` (RL = Reel၊ BK = Break)။
- အတန်းတစ်ခုကို နှိပ်ရင် A4 ကနေ A17 အထိ cell အားလုံးကို Excel နာမည်အတိုင်း ပြပါတယ်။
- ဖော်မြူလာက **12:00 နဲ့ 4:30 ရဲ့ နံပါတ်** နှစ်ခုကိုပဲ သုံးပါတယ် (Excel ထဲမှာ C3,D3 နဲ့ G3,H3)။ ဒီနှစ်ခု မပြည့်သေးရင် `—` ပြပါတယ်။
- **A7 = A5&C5&E5&G5**၊ **E7 = A4&C4&E4&G4** ဖြစ်ပါတယ်။ ၄ လုံးထဲမှာ ဂဏန်းတူ ၂/၃/၄ ကြိမ်ပါနေရင် (ဘေးချင်းကပ်မကပ် မခွဲ) အောက်က ဇယားအတိုင်း အလိုအလျောက် အစားထိုးပါတယ် (ကိုယ်တိုင် ပြင်စရာ မလိုပါ)။ အစားထိုးတဲ့ စာလုံးတွေကို အဲဒီဂဏန်းပါတဲ့ နေရာတွေမှာ ဘယ်ကနေညာ ထည့်ပါတယ်။ ဥပမာ `1886 → 1836`၊ `9111 → 9168`၊ `1213 → 1263`၊ `1122 → 1627`၊ `1212 → 1267`။

| ၂ လုံး | ၃ လုံး | ၄ လုံး |
|---|---|---|
| 11=16 | 111=168 | 1111=1680 |
| 22=27 | 222=274 | 2222=2740 |
| 33=38 | 333=385 | 3333=3850 |
| 44=49 | 444=492 | 4444=4920 |
| 55=50 | 555=503 | 5555=5037 |
| 66=61 | 666=619 | 6666=6190 |
| 77=72 | 777=720 | 7777=7205 |
| 88=83 | 888=831 | 8888=8310 |
| 99=94 | 999=946 | 9999=9460 |
| 00=05 | 000=057 | 0000=0573 |

- A6, E6, A9, E9 က မူလဂဏန်းကိုပဲ သုံးပြီး A8, E8, A10, E10 နဲ့ အောက်က cell တွေက အစားထိုးပြီးသား A7 / E7 ကို သုံးပါတယ် (Excel ထဲက အတိုင်း)။

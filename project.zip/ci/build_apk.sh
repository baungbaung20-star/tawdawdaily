#!/usr/bin/env bash
# Builds a Gradle-based debug APK of Taw Daw Daily (with the native TawDawNotify plugin).
# Runs on a GitHub Actions ubuntu runner. Godot version is pinned below.
set -euo pipefail

GODOT_VER="4.7.2-stable"
GODOT_TPL_VER="4.7.2.stable"
ROOT="$(pwd)"
WORK="$RUNNER_TEMP/godot"
mkdir -p "$WORK"

echo "== Download Godot $GODOT_VER =="
curl -fsSL -o "$WORK/godot.zip" "https://github.com/godotengine/godot/releases/download/$GODOT_VER/Godot_v${GODOT_VER}_linux.x86_64.zip"
unzip -q -o "$WORK/godot.zip" -d "$WORK"
GODOT="$WORK/Godot_v${GODOT_VER}_linux.x86_64"
chmod +x "$GODOT"

echo "== Download export templates (only Android files are extracted) =="
curl -fsSL -o "$WORK/tpl.tpz" "https://github.com/godotengine/godot/releases/download/$GODOT_VER/Godot_v${GODOT_VER}_export_templates.tpz"
TPL_DIR="$HOME/.local/share/godot/export_templates/$GODOT_TPL_VER"
mkdir -p "$TPL_DIR"
unzip -q -o -j "$WORK/tpl.tpz" "templates/android_source.zip" "templates/android_debug.apk" "templates/android_release.apk" "templates/version.txt" -d "$TPL_DIR"
cat "$TPL_DIR/version.txt"

echo "== Android SDK =="
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
export ANDROID_HOME="$SDK"
SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"
if [ ! -x "$SDKM" ]; then
  SDKM="$(ls "$SDK"/cmdline-tools/*/bin/sdkmanager | head -n1)"
fi
yes | "$SDKM" --licenses >/dev/null || true
"$SDKM" "platform-tools" "platforms;android-36" "build-tools;36.1.0" "cmdline-tools;latest" "ndk;29.0.14206865"

echo "== Editor settings =="
mkdir -p "$HOME/.config/godot"
cat > "$HOME/.config/godot/editor_settings-4.tres" <<EOF
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/android_sdk_path = "$SDK"
export/android/java_sdk_path = "$JAVA_HOME"
export/android/debug_keystore = "$ROOT/ci/debug.keystore"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
EOF

echo "== Install Android Gradle build template + native plugin =="
mkdir -p android/build
unzip -q -o "$TPL_DIR/android_source.zip" -d android/build
cp "$TPL_DIR/version.txt" android/.build_version
touch android/build/.gdignore
mkdir -p android/build/src/main/java/com/tawdaw/daily
cp android_plugin/java/com/tawdaw/daily/*.java android/build/src/main/java/com/tawdaw/daily/

echo "== Editor plugin (registers the Android plugin in the manifest) =="
mkdir -p addons/tawdaw_android
cp android_plugin/addon/* addons/tawdaw_android/
if ! grep -q "\[editor_plugins\]" project.godot; then
  printf '\n[editor_plugins]\n\nenabled=PackedStringArray("res://addons/tawdaw_android/plugin.cfg")\n' >> project.godot
fi

echo "== Export preset =="
sed "s|@KEYSTORE@|$ROOT/ci/debug.keystore|" ci/export_presets.cfg > export_presets.cfg

echo "== Import project =="
"$GODOT" --headless --path . --import || true

echo "== Export APK =="
mkdir -p build
"$GODOT" --headless --path . --export-debug "Android" "$ROOT/build/TawDawDaily.apk"
ls -la build
